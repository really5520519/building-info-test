
  # 工区信息管理系统demo (Copy)

  This is a code bundle for 工区信息管理系统demo (Copy). The original project is available at https://www.figma.com/design/kn6wzWJscDQiCXdDP0bLoT/%E5%B7%A5%E5%8C%BA%E4%BF%A1%E6%81%AF%E7%AE%A1%E7%90%86%E7%B3%BB%E7%BB%9Fdemo--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  