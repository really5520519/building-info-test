import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ArrowLeft, MapPin, Info } from 'lucide-react';

interface WorkzoneMapProps {
  onBack: () => void;
  onIconClick: (workzone: any, location: {lat: number, lng: number}) => void;
  onMoreInfo: (workzone: any) => void;
  selectedLocation?: {lat: number, lng: number} | null;
}

// 全局状态管理Google Maps API加载
interface GoogleMapsState {
  isLoaded: boolean;
  isLoading: boolean;
  error: string | null;
}

let globalMapsState: GoogleMapsState = {
  isLoaded: false,
  isLoading: false,
  error: null
};

// 扩展Window接口以包含Google Maps
declare global {
  interface Window {
    google: any;
    initGoogleMapsForWorkzone: () => void;
  }
}

const mockMapData = [
  {
    id: '1',
    name: '上海浦东工区',
    code: 'SHA001',
    location: { lat: 31.2304, lng: 121.4737 },
    address: '上海市浦东新区陆家嘴环路1000号',
    area: 5000,
    workstations: 200,
    businessUsage: 180,
    vacant: 20,
    facilities: 15,
    count: 3,
    city: '上海',
    type: '标准办公',
    status: '已交付'
  },
  {
    id: '2',
    name: '北京中关村工区',
    code: 'BJS002',
    location: { lat: 39.9042, lng: 116.4074 },
    address: '北京市海淀区中关村大街27号',
    area: 3500,
    workstations: 150,
    businessUsage: 0,
    vacant: 150,
    facilities: 12,
    count: 2,
    city: '北京',
    type: '联合办公',
    status: '装修中'
  },
  {
    id: '3',
    name: '深圳南山工区',
    code: 'SZX003',
    location: { lat: 22.5431, lng: 114.0579 },
    address: '深圳市南山区科技园北区朗山路16号',
    area: 6000,
    workstations: 250,
    businessUsage: 230,
    vacant: 20,
    facilities: 18,
    count: 1,
    city: '深圳',
    type: '标准办公',
    status: '已交付'
  },
  {
    id: '4',
    name: '纽约曼哈顿工区',
    code: 'NYC001',
    location: { lat: 40.7128, lng: -74.0060 },
    address: '350 Fifth Avenue, New York, NY 10118',
    area: 4200,
    workstations: 180,
    businessUsage: 160,
    vacant: 20,
    facilities: 14,
    count: 2,
    city: '纽约',
    type: '标准办公',
    status: '已交付'
  },
  {
    id: '5',
    name: '伦敦金丝雀码头工区',
    code: 'LON001',
    location: { lat: 51.5074, lng: -0.1278 },
    address: '1 Canada Square, London E14 5AB, UK',
    area: 3800,
    workstations: 160,
    businessUsage: 140,
    vacant: 20,
    facilities: 12,
    count: 1,
    city: '伦敦',
    type: '创新办公',
    status: '设计中'
  },
  {
    id: '6',
    name: '东京涩谷工区',
    code: 'TYO001',
    location: { lat: 35.6762, lng: 139.6503 },
    address: '2-21-1 Shibuya, Shibuya City, Tokyo 150-0002, Japan',
    area: 4500,
    workstations: 190,
    businessUsage: 170,
    vacant: 20,
    facilities: 16,
    count: 1,
    city: '东京',
    type: '标准办公',
    status: '已交付'
  },
  {
    id: '7',
    name: '新加坡滨海湾工区',
    code: 'SIN001',
    location: { lat: 1.2966, lng: 103.8764 },
    address: '1 Marina Bay, Singapore 018971',
    area: 5200,
    workstations: 220,
    businessUsage: 200,
    vacant: 20,
    facilities: 18,
    count: 3,
    city: '新加坡',
    type: '标准办公',
    status: '已交付'
  },
  {
    id: '8',
    name: '悉尼CBD工区',
    code: 'SYD001',
    location: { lat: -33.8688, lng: 151.2093 },
    address: '100 Market Street, Sydney NSW 2000, Australia',
    area: 3900,
    workstations: 170,
    businessUsage: 150,
    vacant: 20,
    facilities: 13,
    count: 2,
    city: '悉尼',
    type: '标准办公',
    status: '装修中'
  }
];

export default function WorkzoneMap({ onBack, onIconClick, onMoreInfo, selectedLocation }: WorkzoneMapProps) {
  const [selectedWorkzone, setSelectedWorkzone] = useState<any>(null);
  const [hoveredWorkzone, setHoveredWorkzone] = useState<any>(null);
  const [mapInstance, setMapInstance] = useState<any>(null);
  const [markers, setMarkers] = useState<any[]>([]);
  const [isMapReady, setIsMapReady] = useState(false);
  const [mapError, setMapError] = useState<string | null>(null);
  const [filters, setFilters] = useState({
    city: 'all',
    type: 'all',
    status: 'all'
  });
  
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const isInitialized = useRef(false);

  // 根据筛选条件过滤工区数据 - 使用useMemo优化
  const filteredWorkzones = useMemo(() => {
    return mockMapData.filter(workzone => {
      return (
        (filters.city === 'all' || workzone.city === filters.city) &&
        (filters.type === 'all' || workzone.type === filters.type) &&
        (filters.status === 'all' || workzone.status === filters.status)
      );
    });
  }, [filters.city, filters.type, filters.status]);

  // 获取状态颜色
  const getStatusColor = useCallback((status: string) => {
    switch (status) {
      case '已交付': return '#10b981';
      case '装修中': return '#f59e0b';
      case '设计中': return '#6b7280';
      default: return '#3b82f6';
    }
  }, []);

  // 异步加载Google Maps API - 防止重复加载
  const loadGoogleMapsAPI = useCallback(() => {
    return new Promise<void>((resolve, reject) => {
      // 如果已经加载完成
      if (globalMapsState.isLoaded && window.google?.maps) {
        resolve();
        return;
      }

      // 如果正在加载中，等待加载完成
      if (globalMapsState.isLoading) {
        const checkLoading = () => {
          if (globalMapsState.isLoaded) {
            resolve();
          } else if (globalMapsState.error) {
            reject(new Error(globalMapsState.error));
          } else {
            setTimeout(checkLoading, 100);
          }
        };
        checkLoading();
        return;
      }

      // 如果有错误
      if (globalMapsState.error) {
        reject(new Error(globalMapsState.error));
        return;
      }

      // 检查是否已经有script标签
      const existingScript = document.querySelector('script[src*="maps.googleapis.com"]');
      if (existingScript) {
        // 脚本已存在，等待加载
        const checkGoogle = () => {
          if (window.google?.maps) {
            globalMapsState.isLoaded = true;
            globalMapsState.isLoading = false;
            resolve();
          } else {
            setTimeout(checkGoogle, 100);
          }
        };
        checkGoogle();
        return;
      }

      // 开始加载
      globalMapsState.isLoading = true;

      // 设置全局回调函数
      window.initGoogleMapsForWorkzone = () => {
        try {
          if (window.google?.maps) {
            globalMapsState.isLoaded = true;
            globalMapsState.isLoading = false;
            globalMapsState.error = null;
            resolve();
          } else {
            throw new Error('Google Maps API not available after load');
          }
        } catch (error) {
          globalMapsState.error = error instanceof Error ? error.message : 'Unknown error';
          globalMapsState.isLoading = false;
          reject(error);
        }
      };

      // 创建script标签
      const script = document.createElement('script');
      // 使用演示用的API密钥，在实际使用中需要替换
      script.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dOZpQOYOmvQaV4&libraries=marker&loading=async&callback=initGoogleMapsForWorkzone';
      script.async = true;
      script.defer = true;
      script.onerror = () => {
        globalMapsState.error = 'Failed to load Google Maps API';
        globalMapsState.isLoading = false;
        reject(new Error('Failed to load Google Maps API'));
      };
      
      document.head.appendChild(script);
    });
  }, []);

  // 初始化Google地图
  const initMap = useCallback(async (container: HTMLDivElement) => {
    try {
      setMapError(null);
      await loadGoogleMapsAPI();
      
      if (!window.google?.maps) {
        throw new Error('Google Maps API not loaded');
      }

      // 不使用mapId，直接使用自定义样式
      const map = new window.google.maps.Map(container, {
        center: { lat: 31.2304, lng: 121.4737 },
        zoom: 2,
        styles: [
          {
            "featureType": "all",
            "elementType": "geometry.fill",
            "stylers": [{ "weight": "2.00" }]
          },
          {
            "featureType": "all",
            "elementType": "geometry.stroke",
            "stylers": [{ "color": "#9c9c9c" }]
          },
          {
            "featureType": "landscape",
            "elementType": "all",
            "stylers": [{ "color": "#f2f2f2" }]
          },
          {
            "featureType": "landscape",
            "elementType": "geometry.fill",
            "stylers": [{ "color": "#ffffff" }]
          },
          {
            "featureType": "water",
            "elementType": "all",
            "stylers": [{ "color": "#dbeafe" }]
          }
        ]
      });

      setMapInstance(map);
      setIsMapReady(true);

      // 隐藏加载提示
      const loadingOverlay = container.querySelector('[data-loading-overlay]') as HTMLElement;
      if (loadingOverlay) {
        loadingOverlay.style.display = 'none';
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      console.error('Failed to initialize map:', error);
      setMapError(errorMessage);
      
      // 显示错误信息
      const loadingOverlay = container.querySelector('[data-loading-overlay]') as HTMLElement;
      if (loadingOverlay) {
        const errorDiv = loadingOverlay.querySelector('.text-sm') as HTMLElement;
        if (errorDiv) {
          errorDiv.textContent = '地图加载失败';
        }
        const subtitleDiv = loadingOverlay.querySelector('.text-xs') as HTMLElement;
        if (subtitleDiv) {
          subtitleDiv.textContent = errorMessage;
        }
      }
    }
  }, [loadGoogleMapsAPI]);

  // 添加标记到地图 - 使用新的AdvancedMarkerElement API
  const addMarkersToMap = useCallback((map: any, workzones: any[]) => {
    if (!window.google?.maps?.marker?.AdvancedMarkerElement) {
      console.warn('Google Maps AdvancedMarkerElement not available');
      return;
    }

    // 清除现有标记
    markers.forEach(marker => {
      if (marker.map) {
        marker.map = null;
      }
    });
    
    const newMarkers: any[] = [];

    workzones.forEach((workzone) => {
      const isSelected = selectedLocation && 
        Math.abs(workzone.location.lat - selectedLocation.lat) < 0.01 && 
        Math.abs(workzone.location.lng - selectedLocation.lng) < 0.01;

      // 创建自定义标记内容
      const markerElement = document.createElement('div');
      markerElement.innerHTML = `
        <svg width="32" height="32" xmlns="http://www.w3.org/2000/svg">
          <circle cx="16" cy="16" r="14" fill="${isSelected ? '#ef4444' : getStatusColor(workzone.status)}" 
                  stroke="white" stroke-width="4" style="filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1))"/>
          <text x="16" y="20" text-anchor="middle" fill="white" font-size="12" font-weight="500">${workzone.count}</text>
        </svg>
      `;
      markerElement.style.cursor = 'pointer';

      // 使用新的AdvancedMarkerElement API
      const marker = new window.google.maps.marker.AdvancedMarkerElement({
        position: { lat: workzone.location.lat, lng: workzone.location.lng },
        map: map,
        content: markerElement,
        title: workzone.name
      });

      // 添加点击事件
      markerElement.addEventListener('click', () => {
        setSelectedWorkzone(workzone);
        onIconClick(workzone, workzone.location);
      });

      // 添加悬停事件
      markerElement.addEventListener('mouseenter', () => {
        setHoveredWorkzone(workzone);
      });

      markerElement.addEventListener('mouseleave', () => {
        setHoveredWorkzone(null);
      });

      newMarkers.push(marker);
    });

    setMarkers(newMarkers);
  }, [selectedLocation, getStatusColor, onIconClick, markers]);

  // 当地图加载完成且工区数据改变时更新标记
  useEffect(() => {
    if (mapInstance && isMapReady && !mapError) {
      addMarkersToMap(mapInstance, filteredWorkzones);
    }
  }, [mapInstance, isMapReady, mapError, filteredWorkzones, addMarkersToMap]);

  // 初始化地图 - 只在组件挂载时执行一次
  useEffect(() => {
    if (mapContainerRef.current && !isInitialized.current) {
      isInitialized.current = true;
      initMap(mapContainerRef.current);
    }
  }, [initMap]);

  // 组件卸载时清理
  useEffect(() => {
    return () => {
      markers.forEach(marker => {
        if (marker.map) {
          marker.map = null;
        }
      });
    };
  }, [markers]);

  // Google地图渲染
  const MapContainer = () => (
    <div className="relative w-full h-full rounded-lg overflow-hidden border border-border">
      {/* Google地图容器 */}
      <div 
        ref={mapContainerRef}
        id="google-map-container" 
        className="w-full h-full"
      >
        {/* 地图加载提示覆盖层 */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-slate-100 flex items-center justify-center" data-loading-overlay>
          <div className="bg-card/95 backdrop-blur-sm rounded-lg shadow-lg border border-border p-4 text-center">
            <div className="text-sm text-foreground mb-2">全球工区分布地图</div>
            <div className="text-xs text-muted-foreground">
              {mapError ? `错误: ${mapError}` : '正在加载 Google Maps...'}
            </div>
            {mapError && (
              <Button
                size="sm"
                variant="outline"
                className="mt-2"
                onClick={() => {
                  setMapError(null);
                  if (mapContainerRef.current) {
                    isInitialized.current = false;
                    initMap(mapContainerRef.current);
                  }
                }}
              >
                重试
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* 地图上方筛选器 */}
      <div className="absolute top-4 left-4 right-4 bg-card/95 backdrop-blur-sm rounded-lg shadow-lg border border-border p-4 z-20">
        <div className="flex gap-4 items-center">
          <span className="text-sm font-medium text-foreground">筛选条件：</span>
          <Select value={filters.city} onValueChange={(value) => setFilters({ ...filters, city: value })}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="城市" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部城市</SelectItem>
              <SelectItem value="上海">上海</SelectItem>
              <SelectItem value="北京">北京</SelectItem>
              <SelectItem value="深圳">深圳</SelectItem>
              <SelectItem value="纽约">纽约</SelectItem>
              <SelectItem value="伦敦">伦敦</SelectItem>
              <SelectItem value="东京">东京</SelectItem>
              <SelectItem value="新加坡">新加坡</SelectItem>
              <SelectItem value="悉尼">悉尼</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filters.type} onValueChange={(value) => setFilters({ ...filters, type: value })}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="工区类型" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部类型</SelectItem>
              <SelectItem value="标准办公">标准办公</SelectItem>
              <SelectItem value="联合办公">联合办公</SelectItem>
              <SelectItem value="创新办公">创新办公</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filters.status} onValueChange={(value) => setFilters({ ...filters, status: value })}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="状态" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部状态</SelectItem>
              <SelectItem value="已交付">已交付</SelectItem>
              <SelectItem value="装修中">装修中</SelectItem>
              <SelectItem value="设计中">设计中</SelectItem>
            </SelectContent>
          </Select>
          <div className="ml-auto text-sm text-muted-foreground">
            共 {filteredWorkzones.length} 个工区
          </div>
        </div>
      </div>

      {/* 图例 */}
      <div className="absolute top-20 right-4 bg-card/95 backdrop-blur-sm rounded-lg shadow-lg border border-border p-3 z-10">
        <h4 className="font-medium mb-2 text-foreground">图例</h4>
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-primary rounded-full"></div>
            <span className="text-sm text-muted-foreground">工区位置</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-destructive rounded-full"></div>
            <span className="text-sm text-muted-foreground">选中工区</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-sm text-muted-foreground">已交付</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <span className="text-sm text-muted-foreground">装修中</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
            <span className="text-sm text-muted-foreground">设计中</span>
          </div>
        </div>
      </div>

      {/* 悬停信息卡片 */}
      {hoveredWorkzone && (
        <Card className="absolute bottom-20 left-1/2 transform -translate-x-1/2 p-4 w-72 shadow-xl border border-border z-30 bg-card/95 backdrop-blur-sm">
          <div className="space-y-3">
            <div className="font-medium text-foreground">{hoveredWorkzone.name}</div>
            <div className="text-sm text-muted-foreground">{hoveredWorkzone.address}</div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="text-muted-foreground">面积: <span className="text-foreground">{hoveredWorkzone.area}㎡</span></div>
              <div className="text-muted-foreground">工位: <span className="text-foreground">{hoveredWorkzone.workstations}个</span></div>
              <div className="text-muted-foreground">业务使用: <span className="text-foreground">{hoveredWorkzone.businessUsage}个</span></div>
              <div className="text-muted-foreground">空置: <span className="text-foreground">{hoveredWorkzone.vacant}个</span></div>
              <div className="text-muted-foreground">配套: <span className="text-foreground">{hoveredWorkzone.facilities}个</span></div>
              <div className="col-span-2">
                <span className="text-muted-foreground">状态: </span>
                <span className={`px-2 py-1 rounded text-xs ${
                  hoveredWorkzone.status === '已交付' ? 'bg-green-100 text-green-800' :
                  hoveredWorkzone.status === '装修中' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-gray-100 text-gray-800'
                }`}>{hoveredWorkzone.status}</span>
              </div>
            </div>
            <div className="pt-2 border-t border-border">
              <Button
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onMoreInfo(hoveredWorkzone);
                }}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <Info className="w-4 h-4 mr-2" />
                更多信息
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* 头部 */}
      <div className="bg-card border-b border-border px-6 py-4 shadow-sm">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack} className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4" />
            返回
          </Button>
          <div>
            <h1 className="text-lg font-medium text-foreground">工区分布地图</h1>
            <p className="text-sm text-muted-foreground">全球工区分布情况</p>
          </div>
        </div>
      </div>

      {/* 地图区域 */}
      <div className="flex-1 p-6">
        <MapContainer />
      </div>

      {/* 选中工区信息面板 */}
      {selectedWorkzone && (
        <div className="absolute bottom-6 right-6 w-80">
          <Card className="p-4 bg-card/95 backdrop-blur-sm border border-border shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-foreground">{selectedWorkzone.name}</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedWorkzone(null)}
                className="text-muted-foreground hover:text-foreground"
              >
                ×
              </Button>
            </div>
            <div className="space-y-2 text-sm">
              <div><span className="text-muted-foreground">编号:</span> <span className="text-foreground">{selectedWorkzone.code}</span></div>
              <div><span className="text-muted-foreground">地址:</span> <span className="text-foreground">{selectedWorkzone.address}</span></div>
              <div><span className="text-muted-foreground">类型:</span> <span className="text-foreground">{selectedWorkzone.type}</span></div>
              <div><span className="text-muted-foreground">状态:</span> <span className={`px-2 py-1 rounded text-xs ${
                selectedWorkzone.status === '已交付' ? 'bg-green-100 text-green-800' :
                selectedWorkzone.status === '装修中' ? 'bg-yellow-100 text-yellow-800' :
                'bg-gray-100 text-gray-800'
              }`}>{selectedWorkzone.status}</span></div>
              <div className="grid grid-cols-2 gap-2 pt-2">
                <div><span className="text-muted-foreground">面积:</span> <span className="text-foreground">{selectedWorkzone.area}㎡</span></div>
                <div><span className="text-muted-foreground">工位:</span> <span className="text-foreground">{selectedWorkzone.workstations}个</span></div>
                <div><span className="text-muted-foreground">业务使用:</span> <span className="text-foreground">{selectedWorkzone.businessUsage}个</span></div>
                <div><span className="text-muted-foreground">空置:</span> <span className="text-foreground">{selectedWorkzone.vacant}个</span></div>
                <div><span className="text-muted-foreground">配套:</span> <span className="text-foreground">{selectedWorkzone.facilities}个</span></div>
              </div>
              <div className="pt-3 border-t border-border">
                <Button
                  size="sm"
                  onClick={() => onMoreInfo(selectedWorkzone)}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <Info className="w-4 h-4 mr-2" />
                  查看详情
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}