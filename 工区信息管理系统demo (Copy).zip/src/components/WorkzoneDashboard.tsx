import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { MapPin, Plus, Upload, Settings, ArrowUpDown } from 'lucide-react';
import { Pagination, PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from './ui/pagination';

import { mockWorkzones, statisticsData } from './constants/mockData';
import { WorkzoneData } from './constants/types';
import StatCard from './common/StatCard';
import BasicInfoTab from './tabs/BasicInfoTab';
import BusinessInfoTab from './tabs/BusinessInfoTab';
import WorkstationInfoTab from './tabs/WorkstationInfoTab';
import IndependentSpaceTab from './tabs/IndependentSpaceTab';
import LeaseInfoTab from './tabs/LeaseInfoTab';
import DecorationInfoTab from './tabs/DecorationInfoTab';
import DesignInfoTab from './tabs/DesignInfoTab';
import OperationInfoTab from './tabs/OperationInfoTab';
import ComplianceInfoTab from './tabs/ComplianceInfoTab';
import CostInfoTab from './tabs/CostInfoTab';
import BillingInfoTab from './tabs/BillingInfoTab';
interface WorkzoneDashboardProps {
  onWorkzoneSelect: (workzone: WorkzoneData, defaultTab?: string) => void;
  onMapClick: () => void;
  onAddClick: () => void;
}

export default function WorkzoneDashboard({ onWorkzoneSelect, onMapClick, onAddClick }: WorkzoneDashboardProps) {
  const [filters, setFilters] = useState({
    name: '',
    region: 'all',
    type: 'all',
    status: 'all',
    businessType: 'all',
    isActive: 'all',
    hasDrawings: 'all',
    statisticsFilter: 'all'
  });
  
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // 处理统计卡片点击事件，联动下侧列表筛选
  const handleStatisticsClick = (filterType: string) => {
    let newFilters = { ...filters };
    
    switch (filterType) {
      case 'total':
        newFilters.status = 'all';
        break;
      case 'delivered':
        newFilters.status = '已交付';
        break;
      case 'undelivered':
        newFilters.status = '未交付';
        break;
      case 'new':
        newFilters.statisticsFilter = 'new';
        break;
      case 'plannedExit':
        newFilters.statisticsFilter = 'plannedExit';
        break;
      default:
        break;
    }
    
    setFilters(newFilters);
    setCurrentPage(1);
  };



  const filteredWorkzones = mockWorkzones.filter(workzone => {
    return (
      (!filters.name || workzone.name.includes(filters.name) || workzone.code.includes(filters.name)) &&
      (filters.region === 'all' || workzone.region === filters.region) &&
      (filters.type === 'all' || workzone.workzoneType === filters.type) &&
      (filters.status === 'all' || workzone.status === filters.status) &&
      (filters.businessType === 'all' || workzone.businessType === filters.businessType)
    );
  });

  const totalPages = Math.ceil(filteredWorkzones.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const currentWorkzones = filteredWorkzones.slice(startIndex, startIndex + pageSize);

  return (
    <div className="p-6 space-y-6 bg-background">
      {/* 统计区域 */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-medium text-foreground">工区统计</h2>
          <Button onClick={onMapClick} className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground">
            <MapPin className="w-4 h-4" />
            工区地图
          </Button>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-5 gap-4">
            <StatCard title="工区总数" value={statisticsData.workzones.total} filterType="total" className="bg-primary/5" onClick={handleStatisticsClick} />
            <StatCard title="已交付工区" value={statisticsData.workzones.delivered} filterType="delivered" className="bg-green-50" onClick={handleStatisticsClick} />
            <StatCard title="未交付工区" value={statisticsData.workzones.undelivered} filterType="undelivered" className="bg-yellow-50" onClick={handleStatisticsClick} />
            <StatCard title="新增工区" value={statisticsData.workzones.new} filterType="new" className="bg-blue-50" onClick={handleStatisticsClick} />
            <StatCard title="计划退租工区" value={statisticsData.workzones.plannedExit} filterType="plannedExit" className="bg-orange-50" onClick={handleStatisticsClick} />
          </div>

          <div className="grid grid-cols-5 gap-4">
            <StatCard title="工位总数" value={statisticsData.workstations.total} filterType="total" className="bg-primary/5" onClick={handleStatisticsClick} />
            <StatCard title="已交付工位" value={statisticsData.workstations.delivered} filterType="delivered" className="bg-green-50" onClick={handleStatisticsClick} />
            <StatCard title="未交付工位" value={statisticsData.workstations.undelivered} filterType="undelivered" className="bg-yellow-50" onClick={handleStatisticsClick} />
            <StatCard title="新增工位" value={statisticsData.workstations.new} filterType="new" className="bg-blue-50" onClick={handleStatisticsClick} />
            <StatCard title="计划退租工位" value={statisticsData.workstations.plannedExit} filterType="plannedExit" className="bg-orange-50" onClick={handleStatisticsClick} />
          </div>

          <div className="grid grid-cols-5 gap-4">
            <StatCard title="工位面积" value={statisticsData.area.total} filterType="total" className="bg-primary/5" onClick={handleStatisticsClick} />
            <StatCard title="已交付面积" value={statisticsData.area.delivered} filterType="delivered" className="bg-green-50" onClick={handleStatisticsClick} />
            <StatCard title="未交付面积" value={statisticsData.area.undelivered} filterType="undelivered" className="bg-yellow-50" onClick={handleStatisticsClick} />
            <StatCard title="新增面积" value={statisticsData.area.new} filterType="new" className="bg-blue-50" onClick={handleStatisticsClick} />
            <StatCard title="计划退租面积" value={statisticsData.area.plannedExit} filterType="plannedExit" className="bg-orange-50" onClick={handleStatisticsClick} />
          </div>
        </div>
      </div>

      {/* 工区列表区域 */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-medium text-foreground">工区详情</h2>
          <div className="flex gap-2">
            <Button 
              onClick={onAddClick}
              className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <Plus className="w-4 h-4" />
              新增工区
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <Upload className="w-4 h-4" />
              批量更新
            </Button>
          </div>
        </div>

        {/* 筛选区域和按钮 */}
        <div className="flex gap-4 flex-wrap items-center">
          <Input
            placeholder="工区名称/编号"
            value={filters.name}
            onChange={(e) => setFilters({ ...filters, name: e.target.value })}
            className="w-48 border border-border rounded-lg"
          />
          <Select value={filters.region} onValueChange={(value) => setFilters({ ...filters, region: value })}>
            <SelectTrigger className="w-48 border border-border rounded-lg">
              <SelectValue placeholder="大区/国家/地区/城市" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部大区</SelectItem>
              <SelectItem value="华东大区">华东大区</SelectItem>
              <SelectItem value="华北大区">华北大区</SelectItem>
              <SelectItem value="华南大区">华南大区</SelectItem>
              <SelectItem value="西南大区">西南大区</SelectItem>
              <SelectItem value="华中大区">华中大区</SelectItem>
              <SelectItem value="西北大区">西北大区</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filters.type} onValueChange={(value) => setFilters({ ...filters, type: value })}>
            <SelectTrigger className="w-32 border border-border rounded-lg">
              <SelectValue placeholder="工区类型" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部类型</SelectItem>
              <SelectItem value="标准办公">标准办公</SelectItem>
              <SelectItem value="联合办公">联合办公</SelectItem>
              <SelectItem value="创新办公">创新办公</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filters.status} onValueChange={(value) => setFilters({ ...filters, status: value })}>
            <SelectTrigger className="w-32 border border-border rounded-lg">
              <SelectValue placeholder="工区状态" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部状态</SelectItem>
              <SelectItem value="已交付">已交付</SelectItem>
              <SelectItem value="未交付">未交付</SelectItem>
              <SelectItem value="已退租">已退租</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filters.businessType} onValueChange={(value) => setFilters({ ...filters, businessType: value })}>
            <SelectTrigger className="w-32 border border-border rounded-lg">
              <SelectValue placeholder="业务类型" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部业务</SelectItem>
              <SelectItem value="研发中心">研发中心</SelectItem>
              <SelectItem value="技术支持">技术支持</SelectItem>
              <SelectItem value="销售支持">销售支持</SelectItem>
              <SelectItem value="市场营销">市场营销</SelectItem>
              <SelectItem value="产品研发">产品研发</SelectItem>
              <SelectItem value="运营支持">运营支持</SelectItem>
              <SelectItem value="制造支持">制造支持</SelectItem>
              <SelectItem value="物流支持">物流支持</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filters.isActive} onValueChange={(value) => setFilters({ ...filters, isActive: value })}>
            <SelectTrigger className="w-32 border border-border rounded-lg">
              <SelectValue placeholder="是否生效" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              <SelectItem value="是">是</SelectItem>
              <SelectItem value="否">否</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filters.hasDrawings} onValueChange={(value) => setFilters({ ...filters, hasDrawings: value })}>
            <SelectTrigger className="w-36 border border-border rounded-lg">
              <SelectValue placeholder="是否已���传图纸" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部</SelectItem>
              <SelectItem value="是">是</SelectItem>
              <SelectItem value="否">否</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            自定义表头
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <ArrowUpDown className="w-4 h-4" />
            选择排序
          </Button>
        </div>

        {/* Tab列表区域 - 11个Tab */}
        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="grid w-full grid-cols-11 bg-muted">
            <TabsTrigger value="basic" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">基础信息</TabsTrigger>
            <TabsTrigger value="business" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">业务信息</TabsTrigger>
            <TabsTrigger value="workstation" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">工位信息</TabsTrigger>
            <TabsTrigger value="space" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">独立空间</TabsTrigger>
            <TabsTrigger value="lease" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">租赁信息</TabsTrigger>
            <TabsTrigger value="decoration" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">装修信息</TabsTrigger>
            <TabsTrigger value="design" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">设计信息</TabsTrigger>
            <TabsTrigger value="operation" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">运营信息</TabsTrigger>
            <TabsTrigger value="compliance" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">合规信息</TabsTrigger>
            <TabsTrigger value="cost" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">成本信息</TabsTrigger>
            <TabsTrigger value="billing" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">定价信息</TabsTrigger>
          </TabsList>
          
          <TabsContent value="basic" className="mt-4">
            <BasicInfoTab workzones={currentWorkzones} onWorkzoneSelect={onWorkzoneSelect} />
          </TabsContent>

          <TabsContent value="business" className="mt-4">
            <BusinessInfoTab workzones={currentWorkzones} onWorkzoneSelect={onWorkzoneSelect} />
          </TabsContent>
          
          <TabsContent value="workstation" className="mt-4">
            <WorkstationInfoTab workzones={currentWorkzones} onWorkzoneSelect={onWorkzoneSelect} />
          </TabsContent>

          <TabsContent value="space" className="mt-4">
            <IndependentSpaceTab workzones={currentWorkzones} onWorkzoneSelect={onWorkzoneSelect} />
          </TabsContent>

          <TabsContent value="lease" className="mt-4">
            <LeaseInfoTab workzones={currentWorkzones} onWorkzoneSelect={onWorkzoneSelect} />
          </TabsContent>

          <TabsContent value="decoration" className="mt-4">
            <DecorationInfoTab workzones={currentWorkzones} onWorkzoneSelect={onWorkzoneSelect} />
          </TabsContent>
          
          <TabsContent value="design" className="mt-4">
            <DesignInfoTab workzones={currentWorkzones} onWorkzoneSelect={onWorkzoneSelect} />
          </TabsContent>

          <TabsContent value="operation" className="mt-4">
            <OperationInfoTab workzones={currentWorkzones} onWorkzoneSelect={onWorkzoneSelect} />
          </TabsContent>

          <TabsContent value="compliance" className="mt-4">
            <ComplianceInfoTab workzones={currentWorkzones} onWorkzoneSelect={onWorkzoneSelect} />
          </TabsContent>

          <TabsContent value="cost" className="mt-4">
            <CostInfoTab workzones={currentWorkzones} onWorkzoneSelect={onWorkzoneSelect} />
          </TabsContent>

          <TabsContent value="billing" className="mt-4">
            <BillingInfoTab workzones={currentWorkzones} onWorkzoneSelect={onWorkzoneSelect} />
          </TabsContent>
        </Tabs>

        {/* 分页 */}
        <div className="flex items-center justify-end">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground whitespace-nowrap">每页显示</span>
              <Select value={pageSize.toString()} onValueChange={(value) => setPageSize(parseInt(value))}>
                <SelectTrigger className="w-20 border border-border rounded-lg">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="20">20</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                </SelectContent>
              </Select>
              <span className="text-sm text-muted-foreground">条</span>
            </div>
            
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      if (currentPage > 1) setCurrentPage(currentPage - 1);
                    }}
                    className={currentPage <= 1 ? 'pointer-events-none opacity-50' : ''}
                  />
                </PaginationItem>
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const page = i + 1;
                  return (
                    <PaginationItem key={page}>
                      <PaginationLink
                        href="#"
                        isActive={page === currentPage}
                        onClick={(e) => {
                          e.preventDefault();
                          setCurrentPage(page);
                        }}
                      >
                        {page}
                      </PaginationLink>
                    </PaginationItem>
                  );
                })}
                {totalPages > 5 && <PaginationEllipsis />}
                <PaginationItem>
                  <PaginationNext 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                    }}
                    className={currentPage >= totalPages ? 'pointer-events-none opacity-50' : ''}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </div>
        </div>
      </div>


    </div>
  );
}