import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Textarea } from './ui/textarea';
import { ArrowLeft, Sparkles, Upload, Link, FileText, X } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { Badge } from './ui/badge';

interface AddWorkzoneStep2Props {
  onBack: () => void;
  onSubmit: (data: any) => void;
  onSaveDraft?: (data: any) => void;
  initialData?: any;
}

export default function AddWorkzoneStep2({ onBack, onSubmit, onSaveDraft, initialData }: AddWorkzoneStep2Props) {
  const [isPublic, setIsPublic] = useState(true);
  const [showAIDialog, setShowAIDialog] = useState(false);
  const [textType, setTextType] = useState('paste');
  const [aiInputText, setAiInputText] = useState('');
  const [aiInputLink, setAiInputLink] = useState('');
  const [aiInputFile, setAiInputFile] = useState<File | null>(null);
  const [selectedTickets, setSelectedTickets] = useState<string[]>([]);
  const [ticketInput, setTicketInput] = useState('');
  
  const [formData, setFormData] = useState({
    workplaceBusinessType: '',
    businessCategory: '',
    maxBusinessDepartment: '',
    allBusinessDepartments: '',
    specialBusinessDescription: '',
    relatedTickets: []
  });

  // 模拟工单数据
  const mockTickets = [
    { id: 'WO-001', title: '办公区域装修需求' },
    { id: 'WO-002', title: '网络设备配置' },
    { id: 'WO-003', title: '空调系统安装' },
    { id: 'WO-004', title: '安全系统部署' },
    { id: 'WO-005', title: '会议室设备采购' },
    { id: 'WO-006', title: '工位桌椅配置' },
    { id: 'WO-007', title: '照明系统优化' },
    { id: 'WO-008', title: '消防设备检查' }
  ];

  const handleSubmit = () => {
    const combinedData = {
      ...initialData,
      ...formData,
      relatedTickets: selectedTickets,
      isPublic
    };
    onSubmit(combinedData);
  };

  const handleSaveDraft = () => {
    const draftData = {
      ...initialData,
      ...formData,
      relatedTickets: selectedTickets,
      isPublic,
      isDraft: true
    };
    if (onSaveDraft) {
      onSaveDraft(draftData);
    }
    toast.success('草稿已保存');
  };

  const handleAIFill = () => {
    setShowAIDialog(true);
  };

  const handleParseKeywords = () => {
    console.log('解析关键词:', { textType, aiInputText, aiInputLink, aiInputFile });
    
    setTimeout(() => {
      setShowAIDialog(false);
      toast.success('已完成');
      
      setAiInputText('');
      setAiInputLink('');
      setAiInputFile(null);
      setTextType('paste');
    }, 1000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setAiInputFile(file);
    }
  };

  const addTicket = (ticketId: string) => {
    if (!selectedTickets.includes(ticketId)) {
      setSelectedTickets([...selectedTickets, ticketId]);
    }
    setTicketInput('');
  };

  const removeTicket = (ticketId: string) => {
    setSelectedTickets(selectedTickets.filter(id => id !== ticketId));
  };

  const filteredTickets = mockTickets.filter(ticket => 
    ticket.id.toLowerCase().includes(ticketInput.toLowerCase()) ||
    ticket.title.toLowerCase().includes(ticketInput.toLowerCase())
  );

  const FormField = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className="space-y-2">
      <Label className="text-foreground">{label}</Label>
      {children}
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* 头部导航 */}
      <div className="bg-card border-b border-border px-6 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={onBack} className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4" />
              返回
            </Button>
            <div className="flex items-center gap-3">
              <h1 className="text-lg font-medium text-foreground">业务信息</h1>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleAIFill}
                className="flex items-center gap-2 text-primary hover:text-primary hover:bg-primary/5"
              >
                <Sparkles className="w-4 h-4" />
                AI快速填写
              </Button>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">
                  {isPublic ? '公开' : '不公开'}
                </span>
                <Switch
                  checked={isPublic}
                  onCheckedChange={setIsPublic}
                  className={isPublic 
                    ? "data-[state=checked]:bg-primary" 
                    : "data-[state=unchecked]:bg-destructive"
                  }
                />
              </div>
            </div>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          填写工区业务相关信息，完善工区配置
        </p>
      </div>

      <div className="p-6">
        <div className="max-w-6xl mx-auto">
          {/* 填写步骤指示器 */}
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center space-x-8">
              {/* 步骤1 - 基本信息 */}
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium">
                  ✓
                </div>
                <span className="text-muted-foreground">基本信息</span>
              </div>
              
              {/* 连接线1 */}
              <div className="w-16 h-px bg-primary"></div>
              
              {/* 步骤2 - 业务信息 */}
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium">
                  2
                </div>
                <span className="text-primary font-medium">业务信息</span>
              </div>
              
              {/* 连接线2 */}
              <div className="w-16 h-px bg-border"></div>
              
              {/* 步骤3 - 房产信息 */}
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-muted text-muted-foreground flex items-center justify-center text-sm font-medium">
                  3
                </div>
                <span className="text-muted-foreground">房产信息</span>
              </div>
            </div>
          </div>
          
          {/* 整体内容区域添加灰色外框 */}
          <div className="border border-border rounded-lg p-6 bg-card space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <FormField label="职场业务类型">
                <Select value={formData.workplaceBusinessType} onValueChange={(value) => setFormData({...formData, workplaceBusinessType: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="选择职场业务类型" />
                  </SelectTrigger>
                  <SelectContent className="border border-border bg-card">
                    <SelectItem value="研发中心">研发中心</SelectItem>
                    <SelectItem value="销售中心">销售中心</SelectItem>
                    <SelectItem value="客服中心">客服中心</SelectItem>
                    <SelectItem value="运营中心">运营中心</SelectItem>
                    <SelectItem value="管理中心">管理中心</SelectItem>
                    <SelectItem value="综合办公">综合办公</SelectItem>
                  </SelectContent>
                </Select>
              </FormField>

              <FormField label="业务分类">
                <Select value={formData.businessCategory} onValueChange={(value) => setFormData({...formData, businessCategory: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="选择业务分类" />
                  </SelectTrigger>
                  <SelectContent className="border border-border bg-card">
                    <SelectItem value="核心业务">核心业务</SelectItem>
                    <SelectItem value="支撑业务">支撑业务</SelectItem>
                    <SelectItem value="管理业务">管理业务</SelectItem>
                    <SelectItem value="创新业务">创新业务</SelectItem>
                  </SelectContent>
                </Select>
              </FormField>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <FormField label="最大业务部门">
                <Input 
                  value={formData.maxBusinessDepartment} 
                  onChange={(e) => setFormData({...formData, maxBusinessDepartment: e.target.value})}
                  placeholder="输入最大业务部门名称" 
                />
              </FormField>

              <FormField label="所有业务部门">
                <Input 
                  value={formData.allBusinessDepartments} 
                  onChange={(e) => setFormData({...formData, allBusinessDepartments: e.target.value})}
                  placeholder="输入所有业务部门，用逗号分隔" 
                />
              </FormField>
            </div>

            <div className="space-y-4">
              <FormField label="特殊业务说明">
                <Textarea 
                  value={formData.specialBusinessDescription} 
                  onChange={(e) => setFormData({...formData, specialBusinessDescription: e.target.value})}
                  placeholder="请输入特殊业务说明..." 
                  rows={3}
                />
              </FormField>
            </div>

            <div className="space-y-4">
              <FormField label="关联需求工单">
                <div className="space-y-3">
                  <Input 
                    value={ticketInput}
                    onChange={(e) => setTicketInput(e.target.value)}
                    placeholder="搜索工单ID或标题..."
                  />
                  
                  {/* 已选择的工单 */}
                  {selectedTickets.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {selectedTickets.map(ticketId => {
                        const ticket = mockTickets.find(t => t.id === ticketId);
                        return (
                          <Badge key={ticketId} variant="secondary" className="flex items-center gap-1">
                            {ticket?.id}: {ticket?.title}
                            <X 
                              className="w-3 h-3 cursor-pointer hover:text-blue-600" 
                              onClick={() => removeTicket(ticketId)}
                            />
                          </Badge>
                        );
                      })}
                    </div>
                  )}

                  {/* 搜索结果 */}
                  {ticketInput && (
                    <div className="border border-border rounded-md bg-card max-h-40 overflow-y-auto">
                      {filteredTickets.map(ticket => (
                        <div 
                          key={ticket.id}
                          className="p-3 hover:bg-muted cursor-pointer border-b border-border last:border-b-0"
                          onClick={() => addTicket(ticket.id)}
                        >
                          <div className="font-medium text-sm">{ticket.id}</div>
                          <div className="text-xs text-muted-foreground">{ticket.title}</div>
                        </div>
                      ))}
                      {filteredTickets.length === 0 && (
                        <div className="p-3 text-sm text-muted-foreground">
                          未找到匹配的工单
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </FormField>
            </div>

            <div className="flex justify-between gap-3 pt-6">
              <Button 
                variant="outline" 
                onClick={onBack}
                className="text-muted-foreground hover:text-foreground"
              >
                上一步
              </Button>
              
              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  onClick={handleSaveDraft}
                  className="text-muted-foreground hover:text-foreground"
                >
                  存为草稿
                </Button>
                <Button onClick={handleSubmit} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  下一步
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI快速填写弹窗 */}
      <Dialog open={showAIDialog} onOpenChange={setShowAIDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>添加文本到当前页面</DialogTitle>
            <DialogDescription>
              选择文本输入方式，AI将帮助您解析关键词并快速填写表单。
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <div className="space-y-4">
              <Label>文本类型</Label>
              <RadioGroup value={textType} onValueChange={setTextType} className="grid grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="link" id="link" />
                  <Label htmlFor="link" className="flex items-center gap-2 cursor-pointer">
                    <Link className="w-4 h-4" />
                    飞书文档链接
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="upload" id="upload" />
                  <Label htmlFor="upload" className="flex items-center gap-2 cursor-pointer">
                    <Upload className="w-4 h-4" />
                    附件上传
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="paste" id="paste" />
                  <Label htmlFor="paste" className="flex items-center gap-2 cursor-pointer">
                    <FileText className="w-4 h-4" />
                    文本粘贴
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              {textType === 'link' && (
                <div className="space-y-2">
                  <Label>飞书文档链接</Label>
                  <Input
                    value={aiInputLink}
                    onChange={(e) => setAiInputLink(e.target.value)}
                    placeholder="请粘贴飞书文档链接"
                  />
                </div>
              )}

              {textType === 'upload' && (
                <div className="space-y-2">
                  <Label>上传附件</Label>
                  <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                    <input
                      type="file"
                      id="file-upload"
                      className="hidden"
                      onChange={handleFileUpload}
                      accept=".pdf,.doc,.docx,.txt"
                    />
                    <label htmlFor="file-upload" className="cursor-pointer">
                      <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-muted-foreground">
                        {aiInputFile ? aiInputFile.name : '点击上传文件或拖拽文件到此处'}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        支持 PDF、Word、文本文件
                      </p>
                    </label>
                  </div>
                </div>
              )}

              {textType === 'paste' && (
                <div className="space-y-2">
                  <Label>文本内容</Label>
                  <Textarea
                    value={aiInputText}
                    onChange={(e) => setAiInputText(e.target.value)}
                    placeholder="请粘贴或输入文本内容..."
                    rows={6}
                  />
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-border">
            <Button 
              onClick={handleParseKeywords}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
              disabled={
                (textType === 'paste' && !aiInputText.trim()) ||
                (textType === 'link' && !aiInputLink.trim()) ||
                (textType === 'upload' && !aiInputFile)
              }
            >
              解析关键词
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}