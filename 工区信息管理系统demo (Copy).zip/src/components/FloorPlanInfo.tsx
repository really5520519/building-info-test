import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ArrowLeft, ZoomIn, ZoomOut, Download, Building, Printer, Share2 } from 'lucide-react';

interface FloorPlanInfoProps {
  workzone: any;
  onBack: () => void;
}

const mockFloorPlanData = {
  building: {
    office: { area: 3000, workstations: 150, spaces: 8, status: '已交付' },
    support: { area: 800, workstations: 0, spaces: 12, status: '已交付' },
    nonFunctional: { area: 1200, workstations: 0, spaces: 5, status: '已交付' }
  },
  buildings: [
    { id: 'building1', name: '主楼', floors: ['1F', '2F', '3F', 'B1'] },
    { id: 'building2', name: '副楼', floors: ['1F', '2F'] }
  ],
  floors: [
    { id: '1F', name: '1F-办公区', type: 'office', building: 'building1' },
    { id: '2F', name: '2F-会议区', type: 'meeting', building: 'building1' },
    { id: '3F', name: '3F-休闲区', type: 'recreation', building: 'building1' },
    { id: 'B1', name: 'B1-餐饮区', type: 'dining', building: 'building1' },
    { id: '1F_2', name: '1F-储物区', type: 'storage', building: 'building2' },
    { id: '2F_2', name: '2F-设备区', type: 'equipment', building: 'building2' }
  ],
  types: [
    { id: 'office', name: '办公区' },
    { id: 'meeting', name: '会议区' },
    { id: 'recreation', name: '休闲区' },
    { id: 'dining', name: '餐饮区' },
    { id: 'storage', name: '储物区' },
    { id: 'equipment', name: '设备区' }
  ],
  statistics: {
    status: '已交付',
    totalArea: 5000,
    officeArea: 3000,
    supportArea: 800,
    totalWorkstations: 200,
    deliveredWorkstations: 180,
    undeliveredWorkstations: 20,
    totalIndependentSpaces: 25,
    meetingRooms: 15,
    storageRooms: 8
  },
  drawingInfo: {
    number: 'BP-BJ-HD-001',
    status: '已审核',
    version: 'v2.3',
    updateDate: '2023-06-15',
    uploader: '王老五'
  }
};

export default function FloorPlanInfo({ workzone, onBack }: FloorPlanInfoProps) {
  const [zoomLevel, setZoomLevel] = useState(100);
  const [selectedBuilding, setSelectedBuilding] = useState<string>('all');
  const [selectedFloor, setSelectedFloor] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');

  const handleBuildingChange = (value: string) => {
    setSelectedBuilding(value);
  };

  const handleFloorChange = (value: string) => {
    setSelectedFloor(value);
  };

  const handleTypeChange = (value: string) => {
    setSelectedType(value);
  };

  const FloorPlanViewer = () => (
    <div className="relative w-full h-[600px] bg-gradient-to-br from-blue-50 to-slate-100 rounded-lg overflow-hidden border border-border">
      {/* 工具栏 */}
      <div className="absolute top-4 left-4 bg-card/95 backdrop-blur-sm rounded-lg shadow-lg border border-border p-2 z-10 flex gap-2">
        <Button
          size="sm"
          variant="outline"
          onClick={() => setZoomLevel(Math.min(200, zoomLevel + 25))}
          className="h-8 w-8 p-0"
        >
          <ZoomIn className="w-4 h-4" />
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={() => setZoomLevel(Math.max(50, zoomLevel - 25))}
          className="h-8 w-8 p-0"
        >
          <ZoomOut className="w-4 h-4" />
        </Button>
        <span className="px-2 py-1 text-sm bg-muted rounded text-muted-foreground">{zoomLevel}%</span>
        <Button size="sm" variant="outline" className="h-8 w-8 p-0">
          <Download className="w-4 h-4" />
        </Button>
      </div>

      {/* 模拟图纸内容 */}
      <div 
        className="absolute inset-4 bg-card rounded border-2 border-dashed border-border"
        style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top left' }}
      >
        {/* 根据选中楼层和类型显示不同区域 */}
        {(selectedFloor === 'all' || selectedFloor === '1F') && (selectedType === 'all' || selectedType === 'office') && (
          <div className="absolute top-4 left-4 w-64 h-32 bg-primary/20 border-2 border-primary rounded p-2">
            <div className="text-sm font-medium text-primary">办公区</div>
            <div className="text-xs text-primary/80">150个工位</div>
          </div>
        )}
        
        {(selectedFloor === 'all' || selectedFloor === '2F') && (selectedType === 'all' || selectedType === 'meeting') && (
          <div className="absolute top-4 right-4 w-32 h-20 bg-blue-100 border-2 border-blue-500 rounded p-2">
            <div className="text-sm font-medium text-blue-800">会议区</div>
            <div className="text-xs text-blue-600">会议室</div>
          </div>
        )}
        
        {(selectedFloor === 'all' || selectedFloor === 'B1') && (selectedType === 'all' || selectedType === 'dining') && (
          <div className="absolute bottom-20 left-4 w-48 h-24 bg-green-100 border-2 border-green-500 rounded p-2">
            <div className="text-sm font-medium text-green-800">餐饮区</div>
            <div className="text-xs text-green-600">100个餐位</div>
          </div>
        )}

        {/* 非功能区域 */}
        <div className="absolute bottom-4 left-4 w-48 h-16 bg-gray-100 border-2 border-gray-400 rounded p-2">
          <div className="text-sm font-medium text-gray-800">非功能区</div>
          <div className="text-xs text-gray-600">设备间、通道</div>
        </div>

        {/* 工位标记示例 */}
        {(selectedFloor === 'all' || selectedFloor === '1F') && (selectedType === 'all' || selectedType === 'office') && Array.from({ length: 24 }, (_, i) => (
          <div
            key={i}
            className="absolute w-3 h-3 bg-primary rounded-full"
            style={{
              left: `${80 + (i % 8) * 20}px`,
              top: `${60 + Math.floor(i / 8) * 15}px`
            }}
          />
        ))}
      </div>

      {/* 楼层标识 */}
      <div className="absolute bottom-4 right-4 bg-card/95 backdrop-blur-sm rounded-lg shadow-lg border border-border p-3">
        <div className="text-sm font-medium text-foreground">当前选择的楼层区域</div>
        <div className="text-xs text-muted-foreground">比例 1:200</div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* 头部 */}
      <div className="bg-card border-b border-border px-6 py-4 shadow-sm">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack} className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4" />
            返回
          </Button>
          <div>
            <h1 className="text-lg font-medium text-foreground">图纸信息 - {workzone?.name}</h1>
            <p className="text-sm text-muted-foreground">建筑图纸信息及空间布局</p>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* 筛选器区域 */}
        <div className="mb-6 space-y-4">
          <Card className="px-4 py-3 border border-border">
            <div className="flex items-center gap-3 mb-3">
              <Building className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-foreground">筛选条件：</span>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              {/* 楼宇筛选 */}
              <div>
                <h4 className="text-sm font-medium text-foreground mb-2">楼宇筛选</h4>
                <Select value={selectedBuilding} onValueChange={handleBuildingChange}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="选择楼宇" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部楼宇</SelectItem>
                    {mockFloorPlanData.buildings.map((building) => (
                      <SelectItem key={building.id} value={building.id}>
                        {building.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* 楼层筛选 */}
              <div>
                <h4 className="text-sm font-medium text-foreground mb-2">楼层筛选</h4>
                <Select value={selectedFloor} onValueChange={handleFloorChange}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="选择楼层" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部楼层</SelectItem>
                    {mockFloorPlanData.floors
                      .filter(floor => selectedBuilding === 'all' || floor.building === selectedBuilding)
                      .map((floor) => (
                        <SelectItem key={floor.id} value={floor.id}>
                          {floor.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              {/* 类型筛选 */}
              <div>
                <h4 className="text-sm font-medium text-foreground mb-2">类型筛选</h4>
                <Select value={selectedType} onValueChange={handleTypeChange}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="选择类型" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部类型</SelectItem>
                    {mockFloorPlanData.types.map((type) => (
                      <SelectItem key={type.id} value={type.id}>
                        {type.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* 左侧 - 建筑图纸信息 (占3列) */}
          <div className="lg:col-span-3 space-y-6">
            <Card className="p-6 border border-border">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-medium text-foreground">建筑图纸信息</h2>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="h-8 w-8 p-0" title="下载图纸文件">
                    <Download className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="outline" className="h-8 w-8 p-0" title="打印图纸">
                    <Printer className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="outline" className="h-8 w-8 p-0" title="分享链接">
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              {/* 图纸查看器 */}
              <FloorPlanViewer />
            </Card>
          </div>

          {/* 右侧窄栏区 (占1列) */}
          <div className="space-y-6">
            {/* 统计区1 */}
            <Card className="p-4 border border-border">
              <h3 className="font-medium text-foreground mb-4">统计信息</h3>
              
              <div className="space-y-2">
                <Card className="p-3 bg-primary/5 border border-primary/20">
                  <h4 className="font-medium text-primary mb-1">办公区</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">面积:</span>
                      <span className="ml-1 text-foreground">{mockFloorPlanData.building.office.area}㎡</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">工位数:</span>
                      <span className="ml-1 text-foreground">{mockFloorPlanData.building.office.workstations}个</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">空间数:</span>
                      <span className="ml-1 text-foreground">{mockFloorPlanData.building.office.spaces}个</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">状态:</span>
                      <span className="ml-1 text-foreground">{mockFloorPlanData.building.office.status}</span>
                    </div>
                  </div>
                </Card>

                <Card className="p-3 bg-blue-50 border border-blue-200">
                  <h4 className="font-medium text-blue-800 mb-1">配套区</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">面积:</span>
                      <span className="ml-1 text-foreground">{mockFloorPlanData.building.support.area}㎡</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">工位数:</span>
                      <span className="ml-1 text-foreground">{mockFloorPlanData.building.support.workstations}个</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">空间数:</span>
                      <span className="ml-1 text-foreground">{mockFloorPlanData.building.support.spaces}个</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">状态:</span>
                      <span className="ml-1 text-foreground">{mockFloorPlanData.building.support.status}</span>
                    </div>
                  </div>
                </Card>

                <Card className="p-3 bg-gray-50 border border-gray-200">
                  <h4 className="font-medium text-gray-800 mb-1">非功能区</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-muted-foreground">面积:</span>
                      <span className="ml-1 text-foreground">{mockFloorPlanData.building.nonFunctional.area}㎡</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">工位数:</span>
                      <span className="ml-1 text-foreground">{mockFloorPlanData.building.nonFunctional.workstations}个</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">空间数:</span>
                      <span className="ml-1 text-foreground">{mockFloorPlanData.building.nonFunctional.spaces}个</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">状态:</span>
                      <span className="ml-1 text-foreground">{mockFloorPlanData.building.nonFunctional.status}</span>
                    </div>
                  </div>
                </Card>
              </div>
            </Card>

            {/* 图纸信息区2 */}
            <Card className="px-3 py-2.5 border border-border">
              <h4 className="font-medium text-foreground mb-1.5">图纸信息</h4>
              <div className="space-y-1.5 text-sm">
                <div>
                  <div className="text-muted-foreground">图纸编号:</div>
                  <div className="text-foreground font-medium">{mockFloorPlanData.drawingInfo.number}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">状态:</div>
                  <div className="text-foreground font-medium">
                    <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">
                      {mockFloorPlanData.drawingInfo.status}
                    </Badge>
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground">版本:</div>
                  <div className="text-foreground font-medium">{mockFloorPlanData.drawingInfo.version}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">更新日期:</div>
                  <div className="text-foreground font-medium">{mockFloorPlanData.drawingInfo.updateDate}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">上传人:</div>
                  <div className="text-foreground font-medium">{mockFloorPlanData.drawingInfo.uploader}</div>
                </div>
              </div>
            </Card>


          </div>
        </div>
      </div>
    </div>
  );
}