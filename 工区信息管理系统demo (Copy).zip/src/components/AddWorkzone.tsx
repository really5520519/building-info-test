import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Textarea } from './ui/textarea';
import { ArrowLeft, Sparkles, Upload, Link, FileText } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface AddWorkzoneProps {
  onBack: () => void;
  onSubmit: (data: any) => void;
  onSaveDraft?: (data: any) => void;
}

export default function AddWorkzone({ onBack, onSubmit, onSaveDraft }: AddWorkzoneProps) {
  const [isPublic, setIsPublic] = useState(true);
  const [showAIDialog, setShowAIDialog] = useState(false);
  const [textType, setTextType] = useState('paste');
  const [aiInputText, setAiInputText] = useState('');
  const [aiInputLink, setAiInputLink] = useState('');
  const [aiInputFile, setAiInputFile] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    // 第一组：基础信息
    region: '',
    country: '',
    province: '',
    city: '',
    district: '',
    name: '',
    code: '',
    mainDataCode: '',
    postalCode: '',
    businessDistrict: '',
    isPark: '',
    buildingCount: '',
    physicalFloors: '',
    buildingLevel: '',
    address: '',
    // 第二组：业务信息
    businessType: '',
    leaseType: '',
    leaseForm: '',
    isOver100People: '',
    is24Hours: '',
    isHighRise: '',
    specialFunction: '',
    isSharedWorkspace: ''
  });

  const handleSubmit = () => {
    onSubmit({...formData, isPublic});
  };

  const handleSaveDraft = () => {
    const draftData = {...formData, isPublic, isDraft: true};
    if (onSaveDraft) {
      onSaveDraft(draftData);
    }
    toast.success('草稿已保存');
  };

  const handleAIFill = () => {
    setShowAIDialog(true);
  };

  const handleParseKeywords = () => {
    // TODO: 实现AI解析关键词逻辑
    console.log('解析关键词:', { textType, aiInputText, aiInputLink, aiInputFile });
    
    // 模拟AI解析过程
    setTimeout(() => {
      setShowAIDialog(false);
      toast.success('已完成');
      
      // 重置AI输入状态
      setAiInputText('');
      setAiInputLink('');
      setAiInputFile(null);
      setTextType('paste');
    }, 1000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setAiInputFile(file);
    }
  };

  const FormField = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className="space-y-2">
      <Label className="text-foreground">{label}</Label>
      {children}
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* 头部导航 */}
      <div className="bg-card border-b border-border px-6 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={onBack} className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4" />
              返回
            </Button>
            <div className="flex items-center gap-3">
              <h1 className="text-lg font-medium text-foreground">基础信息</h1>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleAIFill}
                className="flex items-center gap-2 text-primary hover:text-primary hover:bg-primary/5"
              >
                <Sparkles className="w-4 h-4" />
                AI快速填写
              </Button>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">
                  {isPublic ? '公开' : '不公开'}
                </span>
                <Switch
                  checked={isPublic}
                  onCheckedChange={setIsPublic}
                  className={isPublic 
                    ? "data-[state=checked]:bg-primary" 
                    : "data-[state=unchecked]:bg-destructive"
                  }
                />
              </div>
            </div>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          填写工区基础信息，完成后可进入详情页面进行进一步编辑
        </p>
      </div>

      <div className="p-6">
        <div className="max-w-6xl mx-auto">
          {/* 填写步骤指示器 */}
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center space-x-8">
              {/* 步骤1 - 基本信息 */}
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium">
                  1
                </div>
                <span className="text-primary font-medium">基本信息</span>
              </div>
              
              {/* 连接线1 */}
              <div className="w-16 h-px bg-border"></div>
              
              {/* 步骤2 - 业务信息 */}
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-muted text-muted-foreground flex items-center justify-center text-sm font-medium">
                  2
                </div>
                <span className="text-muted-foreground">业务信息</span>
              </div>
              
              {/* 连接线2 */}
              <div className="w-16 h-px bg-border"></div>
              
              {/* 步骤3 - 房产信息 */}
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-muted text-muted-foreground flex items-center justify-center text-sm font-medium">
                  3
                </div>
                <span className="text-muted-foreground">房产信息</span>
              </div>
            </div>
          </div>
          
          {/* 整体内容区域添加灰色外框 */}
          <div className="border border-border rounded-lg p-6 bg-card space-y-6">
            {/* 第一组：基础信息 */}
            <div className="space-y-6">
              <div className="grid grid-cols-4 gap-4">
                <FormField label="房产分区">
                  <Select value={formData.region} onValueChange={(value) => setFormData({...formData, region: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择房产分区" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="华东大区">华东大区</SelectItem>
                      <SelectItem value="华北大区">华北大区</SelectItem>
                      <SelectItem value="华南大区">华南大区</SelectItem>
                      <SelectItem value="西南大区">西南大区</SelectItem>
                      <SelectItem value="华中大区">华中大区</SelectItem>
                      <SelectItem value="西北大区">西北大区</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>

                <FormField label="国家/地区">
                  <Select value={formData.country} onValueChange={(value) => setFormData({...formData, country: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择国家/地区" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="中国">中国</SelectItem>
                      <SelectItem value="美国">美国</SelectItem>
                      <SelectItem value="新加坡">新加坡</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>

                <FormField label="省/州">
                  <Select value={formData.province} onValueChange={(value) => setFormData({...formData, province: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择省/州" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="上海市">上海市</SelectItem>
                      <SelectItem value="北京市">北京市</SelectItem>
                      <SelectItem value="广东省">广东省</SelectItem>
                      <SelectItem value="浙江省">浙江省</SelectItem>
                      <SelectItem value="江苏省">江苏省</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>

                <FormField label="城市">
                  <Select value={formData.city} onValueChange={(value) => setFormData({...formData, city: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择城市" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="上海市">上海市</SelectItem>
                      <SelectItem value="北京市">北京市</SelectItem>
                      <SelectItem value="深圳市">深圳市</SelectItem>
                      <SelectItem value="杭州市">杭州市</SelectItem>
                      <SelectItem value="南京市">南京市</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>
              </div>

              <div className="grid grid-cols-4 gap-4">
                <FormField label="区县">
                  <Select value={formData.district} onValueChange={(value) => setFormData({...formData, district: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择区县" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="浦东新区">浦东新区</SelectItem>
                      <SelectItem value="黄浦区">黄浦区</SelectItem>
                      <SelectItem value="静安区">静安区</SelectItem>
                      <SelectItem value="徐汇区">徐汇区</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>

                <FormField label="工区名称">
                  <Input 
                    value={formData.name} 
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="输入工区名称" 
                  />
                </FormField>

                <FormField label="工区编号">
                  <Input 
                    value={formData.code} 
                    onChange={(e) => setFormData({...formData, code: e.target.value})}
                    placeholder="输入工区编号" 
                  />
                </FormField>

                <FormField label="工区主数据编码">
                  <Input 
                    value={formData.mainDataCode} 
                    onChange={(e) => setFormData({...formData, mainDataCode: e.target.value})}
                    placeholder="输入主数据编码" 
                  />
                </FormField>
              </div>

              <div className="grid grid-cols-4 gap-4">
                <FormField label="邮政编码">
                  <Input 
                    value={formData.postalCode} 
                    onChange={(e) => setFormData({...formData, postalCode: e.target.value})}
                    placeholder="输入邮政编码" 
                  />
                </FormField>

                <FormField label="办公室所属商圈/区位">
                  <Input 
                    value={formData.businessDistrict} 
                    onChange={(e) => setFormData({...formData, businessDistrict: e.target.value})}
                    placeholder="输入商圈/区位" 
                  />
                </FormField>

                <FormField label="是否园区">
                  <Select value={formData.isPark} onValueChange={(value) => setFormData({...formData, isPark: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="是">是</SelectItem>
                      <SelectItem value="否">否</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>

                <FormField label="楼栋数">
                  <Input 
                    type="number"
                    value={formData.buildingCount} 
                    onChange={(e) => setFormData({...formData, buildingCount: e.target.value})}
                    placeholder="输入楼栋数" 
                  />
                </FormField>
              </div>

              <div className="grid grid-cols-4 gap-4">
                <FormField label="楼层数">
                  <Input 
                    type="number"
                    value={formData.physicalFloors} 
                    onChange={(e) => setFormData({...formData, physicalFloors: e.target.value})}
                    placeholder="输入楼层数" 
                  />
                </FormField>

                <FormField label="等级标准">
                  <Select value={formData.buildingLevel} onValueChange={(value) => setFormData({...formData, buildingLevel: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择等级标准" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="A级">A级</SelectItem>
                      <SelectItem value="B+级">B+级</SelectItem>
                      <SelectItem value="B级">B级</SelectItem>
                      <SelectItem value="C级">C级</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>

                <FormField label="合同地址">
                  <Input 
                    value={formData.address} 
                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                    placeholder="输入合同地址" 
                  />
                </FormField>
              </div>
            </div>

            {/* 分隔线 */}
            <div className="flex items-center justify-center py-4">
              <div className="flex-1 h-px bg-border"></div>
            </div>

            {/* 第二组：业务信息 */}
            <div className="space-y-6">
              <div className="grid grid-cols-4 gap-4">
                <FormField label="业务类型">
                  <Select value={formData.businessType} onValueChange={(value) => setFormData({...formData, businessType: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择业务类型" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="研发中心">研发中心</SelectItem>
                      <SelectItem value="技术支持">技术支持</SelectItem>
                      <SelectItem value="销售支持">销售支持</SelectItem>
                      <SelectItem value="市场营销">市场营销</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>

                <FormField label="租赁类型">
                  <Select value={formData.leaseType} onValueChange={(value) => setFormData({...formData, leaseType: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择租赁类型" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="租赁">租赁</SelectItem>
                      <SelectItem value="自有">自有</SelectItem>
                      <SelectItem value="合作">合作</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>

                <FormField label="租赁形式">
                  <Select value={formData.leaseForm} onValueChange={(value) => setFormData({...formData, leaseForm: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择租赁形式" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="整租">整租</SelectItem>
                      <SelectItem value="分租">分租</SelectItem>
                      <SelectItem value="联合租赁">联合租赁</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>

                <FormField label="是否大于100人">
                  <Select value={formData.isOver100People} onValueChange={(value) => setFormData({...formData, isOver100People: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="是">是</SelectItem>
                      <SelectItem value="否">否</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>
              </div>

              <div className="grid grid-cols-4 gap-4">
                <FormField label="是否24h职场">
                  <Select value={formData.is24Hours} onValueChange={(value) => setFormData({...formData, is24Hours: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="是">是</SelectItem>
                      <SelectItem value="否">否</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>

                <FormField label="是否高层建筑">
                  <Select value={formData.isHighRise} onValueChange={(value) => setFormData({...formData, isHighRise: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="是">是</SelectItem>
                      <SelectItem value="否">否</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>

                <FormField label="特殊功能/用途">
                  <Input 
                    value={formData.specialFunction} 
                    onChange={(e) => setFormData({...formData, specialFunction: e.target.value})}
                    placeholder="输入特殊功能" 
                  />
                </FormField>

                <FormField label="是否共享工位">
                  <Select value={formData.isSharedWorkspace} onValueChange={(value) => setFormData({...formData, isSharedWorkspace: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择" />
                    </SelectTrigger>
                    <SelectContent className="border border-border bg-card">
                      <SelectItem value="是">是</SelectItem>
                      <SelectItem value="否">否</SelectItem>
                    </SelectContent>
                  </Select>
                </FormField>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-6">
              <Button 
                variant="outline" 
                onClick={handleSaveDraft}
                className="text-muted-foreground hover:text-foreground"
              >
                存为草稿
              </Button>
              <Button onClick={handleSubmit} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                下一步
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* AI快速填写弹窗 */}
      <Dialog open={showAIDialog} onOpenChange={setShowAIDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>添加文本到当前页面</DialogTitle>
            <DialogDescription>
              选择文本输入方式，AI将帮助您解析关键词并快速填写表单。
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <div className="space-y-4">
              <Label>文本类型</Label>
              <RadioGroup value={textType} onValueChange={setTextType} className="grid grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="link" id="link" />
                  <Label htmlFor="link" className="flex items-center gap-2 cursor-pointer">
                    <Link className="w-4 h-4" />
                    飞书文档链接
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="upload" id="upload" />
                  <Label htmlFor="upload" className="flex items-center gap-2 cursor-pointer">
                    <Upload className="w-4 h-4" />
                    附件上传
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="paste" id="paste" />
                  <Label htmlFor="paste" className="flex items-center gap-2 cursor-pointer">
                    <FileText className="w-4 h-4" />
                    文本粘贴
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              {textType === 'link' && (
                <div className="space-y-2">
                  <Label>飞书文档链接</Label>
                  <Input
                    value={aiInputLink}
                    onChange={(e) => setAiInputLink(e.target.value)}
                    placeholder="请粘贴飞书文档链接"
                  />
                </div>
              )}

              {textType === 'upload' && (
                <div className="space-y-2">
                  <Label>上传附件</Label>
                  <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                    <input
                      type="file"
                      id="file-upload"
                      className="hidden"
                      onChange={handleFileUpload}
                      accept=".pdf,.doc,.docx,.txt"
                    />
                    <label htmlFor="file-upload" className="cursor-pointer">
                      <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-muted-foreground">
                        {aiInputFile ? aiInputFile.name : '点击上传文件或拖拽文件到此处'}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        支持 PDF、Word、文本文件
                      </p>
                    </label>
                  </div>
                </div>
              )}

              {textType === 'paste' && (
                <div className="space-y-2">
                  <Label>文本内容</Label>
                  <Textarea
                    value={aiInputText}
                    onChange={(e) => setAiInputText(e.target.value)}
                    placeholder="请粘贴或输入文本内容..."
                    rows={6}
                  />
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-border">
            <Button 
              onClick={handleParseKeywords}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
              disabled={
                (textType === 'paste' && !aiInputText.trim()) ||
                (textType === 'link' && !aiInputLink.trim()) ||
                (textType === 'upload' && !aiInputFile)
              }
            >
              解析关键词
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}