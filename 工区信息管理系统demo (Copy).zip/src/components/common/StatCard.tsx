import React from 'react';
import { Card } from '../ui/card';

interface StatCardProps {
  title: string;
  value: number;
  filterType?: string;
  className?: string;
  onClick?: (filterType: string) => void;
}

export default function StatCard({ title, value, filterType, className = "", onClick }: StatCardProps) {
  const handleClick = () => {
    if (onClick && filterType) {
      onClick(filterType);
    }
  };

  return (
    <Card 
      className={`p-4 border border-border ${onClick ? 'cursor-pointer hover:shadow-md transition-shadow' : ''} ${className}`}
      onClick={handleClick}
    >
      <div className="text-center">
        <div className="text-sm text-muted-foreground mb-2">{title}</div>
        <div className="text-2xl font-medium text-foreground">{value.toLocaleString()}</div>
      </div>
    </Card>
  );
}