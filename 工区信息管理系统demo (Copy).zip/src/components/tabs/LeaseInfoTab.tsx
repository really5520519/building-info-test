import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { WorkzoneData } from '../constants/types';

interface LeaseInfoTabProps {
  workzones: WorkzoneData[];
  onWorkzoneSelect: (workzone: WorkzoneData, defaultTab?: string) => void;
}

export default function LeaseInfoTab({ workzones, onWorkzoneSelect }: LeaseInfoTabProps) {
  return (
    <div className="border border-border rounded-lg overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="whitespace-nowrap sticky left-0 bg-muted/50 z-10 text-foreground">工区名称</TableHead>
            <TableHead className="whitespace-nowrap sticky left-24 bg-muted/50 z-10 text-foreground">工区编号</TableHead>
            <TableHead className="whitespace-nowrap sticky left-48 bg-muted/50 z-10 text-foreground">工区状态</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">整体租期（最早-最晚）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">合同主体/我方主体名称</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">业主/对方主体名称</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">历史所有合同总数</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">历史租赁总面积</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">历史签署合同总金额</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">历史签署物业费总金额</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">历史平均表面租金（元/平方米/天）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">历史平均有效租金（元/平方米/天）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">有效合同数（不含物业和协议）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">有效租赁面积</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">有效租赁合同总金额</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">有效物业费总金额</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">物业费标准（元/平方米/月）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">平均月租金</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">租赁总成本（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">租赁成本（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">租金成本（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">物业成本（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">其他费用（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">『押金/保证金』总金额（本次）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">表面租金（元/平方米/天）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">有效租金（元/平方米/天）</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {workzones.map((workzone) => (
            <TableRow key={workzone.id} className="hover:bg-muted/50">
              <TableCell className="whitespace-nowrap sticky left-0 bg-background">
                <button
                  className="text-primary hover:text-primary/80 hover:underline font-medium"
                  onClick={() => onWorkzoneSelect(workzone)}
                >
                  {workzone.name}
                </button>
              </TableCell>
              <TableCell className="whitespace-nowrap sticky left-24 bg-background text-muted-foreground">{workzone.code}</TableCell>
              <TableCell className="whitespace-nowrap sticky left-48 bg-background">
                <Badge variant={
                  workzone.status === '已交付' ? 'default' : 
                  workzone.status === '已退租' ? 'destructive' : 
                  'secondary'
                }>
                  {workzone.status}
                </Badge>
              </TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">2023-2028</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">某某科技有限公司</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">某某地产发展有限公司</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">1</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.area}㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 300)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 60)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">8.2</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">7.8</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">1</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.area}㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 300)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 60)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">50</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 5)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 360)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 300)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 300)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 60)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 10)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 20)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">8.2</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">7.8</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}