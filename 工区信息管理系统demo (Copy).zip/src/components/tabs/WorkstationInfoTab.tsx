import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { WorkzoneData } from '../constants/types';

interface WorkstationInfoTabProps {
  workzones: WorkzoneData[];
  onWorkzoneSelect: (workzone: WorkzoneData, defaultTab?: string) => void;
}

export default function WorkstationInfoTab({ workzones, onWorkzoneSelect }: WorkstationInfoTabProps) {
  return (
    <div className="border border-border rounded-lg overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="whitespace-nowrap sticky left-0 bg-muted/50 z-10 text-foreground">工区名称</TableHead>
            <TableHead className="whitespace-nowrap sticky left-24 bg-muted/50 z-10 text-foreground">工区编号</TableHead>
            <TableHead className="whitespace-nowrap sticky left-48 bg-muted/50 z-10 text-foreground">工区状态</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">总工位数（工区）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">已交付工位数（工区）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">未交付工位数（工区）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">已退租工位数（工区）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工区已交付租赁面积</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工区未交付租赁面积</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工区已退租租赁面积</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">使用周期</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">起租日期（工区）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">到期日期（工区）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">实际退租日期（工区）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">实际交付日期</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">搬家入住日期（=day1&启用日期）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">建筑面积</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">租赁面积</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">使用面积（工区）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">得房率</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">使用率</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {workzones.map((workzone) => (
            <TableRow key={workzone.id} className="hover:bg-muted/50">
              <TableCell className="whitespace-nowrap sticky left-0 bg-background">
                <button
                  className="text-primary hover:text-primary/80 hover:underline font-medium"
                  onClick={() => onWorkzoneSelect(workzone)}
                >
                  {workzone.name}
                </button>
              </TableCell>
              <TableCell className="whitespace-nowrap sticky left-24 bg-background text-muted-foreground">{workzone.code}</TableCell>
              <TableCell className="whitespace-nowrap sticky left-48 bg-background">
                <Badge variant={
                  workzone.status === '已交付' ? 'default' : 
                  workzone.status === '已退租' ? 'destructive' : 
                  'secondary'
                }>
                  {workzone.status}
                </Badge>
              </TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.workstations}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '已交付' ? workzone.workstations : 0}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status !== '已交付' ? workzone.workstations : 0}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '已交付' ? workzone.area : 0}㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status !== '已交付' ? workzone.area : 0}㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">0㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">5年</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">2023-01-01</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">2028-01-01</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '已交付' ? '2023-03-15' : '-'}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '已交付' ? '2023-04-01' : '-'}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 1.2)}㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.area}㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.85)}㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">85%</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round((workzone.businessUsage / workzone.workstations) * 100)}%</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}