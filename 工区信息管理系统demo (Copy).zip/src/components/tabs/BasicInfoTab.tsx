import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { WorkzoneData } from '../constants/types';
import { Edit, Trash2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface BasicInfoTabProps {
  workzones: WorkzoneData[];
  onWorkzoneSelect: (workzone: WorkzoneData, defaultTab?: string) => void;
}

export default function BasicInfoTab({ workzones, onWorkzoneSelect }: BasicInfoTabProps) {
  const handleEdit = (workzone: WorkzoneData) => {
    console.log('编辑工区:', workzone.id);
    onWorkzoneSelect(workzone);
  };

  const handleDelete = (workzone: WorkzoneData) => {
    console.log('删除工区:', workzone.id);
    toast.success(`删除工区"${workzone.name}"功能开发中`);
  };

  return (
    <div className="border border-border rounded-lg overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="whitespace-nowrap text-foreground">房产分区</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">国家/地区</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">省/州</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">城市</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">区县</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工区名称</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工区编号</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工区主数据编码</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工区状态</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">业务类型</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工区类型</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">合同地址</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">邮政编码</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">办公室所属商圈/区位</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">办公楼等级标准</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">租赁类型</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">租赁形式</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否整租</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否24h工区</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否高层建筑</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工区特殊功能/用途</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否保密工区</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否共享工位工区</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否园区</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">楼栋数</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">物理楼层数量</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">电梯楼层数量</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">操作</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {workzones.map((workzone) => (
            <TableRow key={workzone.id} className="hover:bg-muted/50">
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.region}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.country}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.province}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.city}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.district}</TableCell>
              <TableCell className="whitespace-nowrap">
                <button
                  className="text-primary hover:text-primary/80 hover:underline font-medium"
                  onClick={() => onWorkzoneSelect(workzone)}
                >
                  {workzone.name}
                </button>
              </TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.code}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.mainDataCode}</TableCell>
              <TableCell className="whitespace-nowrap">
                <Badge variant={
                  workzone.status === '已交付' ? 'default' : 
                  workzone.status === '已退租' ? 'destructive' : 
                  'secondary'
                }>
                  {workzone.status}
                </Badge>
              </TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.businessType}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.workzoneType}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.address}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.postalCode}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.businessDistrict}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.buildingLevel}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.leaseType}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.leaseForm}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.isFullLease ? '是' : '否'}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.is24Hours ? '是' : '否'}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.isHighRise ? '是' : '否'}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.specialFunction}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.isConfidential ? '是' : '否'}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.isSharedWorkspace ? '是' : '否'}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.isPark ? '是' : '否'}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.buildingCount}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.physicalFloors}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.elevatorFloors}</TableCell>
              <TableCell className="whitespace-nowrap">
                <div className="flex items-center gap-2">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleEdit(workzone)}
                    className="flex items-center gap-1 text-blue-600 hover:text-blue-700 px-2 py-1"
                  >
                    <Edit className="w-3 h-3" />
                    编辑
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleDelete(workzone)}
                    className="flex items-center gap-1 text-blue-600 hover:text-blue-700 px-2 py-1"
                  >
                    <Trash2 className="w-3 h-3" />
                    删除
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}