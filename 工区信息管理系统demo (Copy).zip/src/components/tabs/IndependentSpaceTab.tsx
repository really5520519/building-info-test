import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { WorkzoneData } from '../constants/types';

interface IndependentSpaceTabProps {
  workzones: WorkzoneData[];
  onWorkzoneSelect: (workzone: WorkzoneData, defaultTab?: string) => void;
}

export default function IndependentSpaceTab({ workzones, onWorkzoneSelect }: IndependentSpaceTabProps) {
  return (
    <div className="border border-border rounded-lg overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="whitespace-nowrap sticky left-0 bg-muted/50 z-10 text-foreground">工区名称</TableHead>
            <TableHead className="whitespace-nowrap sticky left-24 bg-muted/50 z-10 text-foreground">工区编号</TableHead>
            <TableHead className="whitespace-nowrap sticky left-48 bg-muted/50 z-10 text-foreground">工区状态</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">办公空间数量(面积)</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">会议协作空间数量(面积)</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">业务特殊空间数量(面积)</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">支持功能空间数量(面积)</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">服务配套空间-康体数量(面积)</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">服务配套空间-餐饮数量(面积)</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">访客空间数量(面积)</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">配套服务空间-运营数量(面积)</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">未定义空间数量(面积)</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">非使用面积空间(面积)</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {workzones.map((workzone) => (
            <TableRow key={workzone.id} className="hover:bg-muted/50">
              <TableCell className="whitespace-nowrap sticky left-0 bg-background">
                <button
                  className="text-primary hover:text-primary/80 hover:underline font-medium"
                  onClick={() => onWorkzoneSelect(workzone)}
                >
                  {workzone.name}
                </button>
              </TableCell>
              <TableCell className="whitespace-nowrap sticky left-24 bg-background text-muted-foreground">{workzone.code}</TableCell>
              <TableCell className="whitespace-nowrap sticky left-48 bg-background">
                <Badge variant={
                  workzone.status === '已交付' ? 'default' : 
                  workzone.status === '已退租' ? 'destructive' : 
                  'secondary'
                }>
                  {workzone.status}
                </Badge>
              </TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.8)}个({Math.round(workzone.area * 0.6)}㎡)</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.15)}个({Math.round(workzone.area * 0.1)}㎡)</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.05)}个({Math.round(workzone.area * 0.05)}㎡)</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.facilities * 0.4)}个({Math.round(workzone.area * 0.08)}㎡)</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.facilities * 0.1)}个({Math.round(workzone.area * 0.03)}㎡)</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.facilities * 0.2)}个({Math.round(workzone.area * 0.05)}㎡)</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.facilities * 0.1)}个({Math.round(workzone.area * 0.02)}㎡)</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.facilities * 0.2)}个({Math.round(workzone.area * 0.04)}㎡)</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">2个({Math.round(workzone.area * 0.01)}㎡)</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">设备间等({Math.round(workzone.area * 0.12)}㎡)</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}