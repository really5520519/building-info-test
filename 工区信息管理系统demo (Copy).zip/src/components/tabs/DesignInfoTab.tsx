import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { WorkzoneData } from '../constants/types';

interface DesignInfoTabProps {
  workzones: WorkzoneData[];
  onWorkzoneSelect: (workzone: WorkzoneData, defaultTab?: string) => void;
}

export default function DesignInfoTab({ workzones, onWorkzoneSelect }: DesignInfoTabProps) {
  return (
    <div className="border border-border rounded-lg overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="whitespace-nowrap sticky left-0 bg-muted/50 z-10 text-foreground">工区名称</TableHead>
            <TableHead className="whitespace-nowrap sticky left-24 bg-muted/50 z-10 text-foreground">工区编号</TableHead>
            <TableHead className="whitespace-nowrap sticky left-48 bg-muted/50 z-10 text-foreground">工区状态</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">密度档位（AB档）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">层高（楼板高度）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">层高（吊顶高度）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">楼层布局</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">自然采光（窗户7.5米工位覆盖率）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">承重信息</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">玻璃幕墙占比</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工位区使用面积（工区）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">单工位租赁面积（工区）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">单工位使用面积（工区）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">各性质工位数量（新4类）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">各尺寸工位数量</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">各类工位样式数量</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">各使用方式数量</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">各类配套信息数量</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {workzones.map((workzone) => (
            <TableRow key={workzone.id} className="hover:bg-muted/50">
              <TableCell className="whitespace-nowrap sticky left-0 bg-background">
                <button
                  className="text-primary hover:text-primary/80 hover:underline font-medium"
                  onClick={() => onWorkzoneSelect(workzone)}
                >
                  {workzone.name}
                </button>
              </TableCell>
              <TableCell className="whitespace-nowrap sticky left-24 bg-background text-muted-foreground">{workzone.code}</TableCell>
              <TableCell className="whitespace-nowrap sticky left-48 bg-background">
                <Badge variant={
                  workzone.status === '已交付' ? 'default' : 
                  workzone.status === '已退租' ? 'destructive' : 
                  'secondary'
                }>
                  {workzone.status}
                </Badge>
              </TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">A档</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">3.8米</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">2.8米</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">开放式办公</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">85%</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">800kg/㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">60%</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.6)}㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area / workzone.workstations)}㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round((workzone.area * 0.85) / workzone.workstations)}㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">标准工位{Math.round(workzone.workstations * 0.9)}个，高级工位{Math.round(workzone.workstations * 0.1)}个</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">1.2米{Math.round(workzone.workstations * 0.6)}个，1.4米{Math.round(workzone.workstations * 0.3)}个，1.6米{Math.round(workzone.workstations * 0.1)}个</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">开放式{Math.round(workzone.workstations * 0.9)}个，半开放式{Math.round(workzone.workstations * 0.1)}个</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">固定工位{Math.round(workzone.workstations * 0.75)}个，共享工位{Math.round(workzone.workstations * 0.25)}个</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">会议室{Math.round(workzone.facilities * 0.6)}个，休息区{Math.round(workzone.facilities * 0.2)}个，茶水间{Math.round(workzone.facilities * 0.2)}个</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}