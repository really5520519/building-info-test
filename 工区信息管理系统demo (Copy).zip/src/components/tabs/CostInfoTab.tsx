import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { WorkzoneData } from '../constants/types';

interface CostInfoTabProps {
  workzones: WorkzoneData[];
  onWorkzoneSelect: (workzone: WorkzoneData, defaultTab?: string) => void;
}

export default function CostInfoTab({ workzones, onWorkzoneSelect }: CostInfoTabProps) {
  return (
    <div className="border border-border rounded-lg overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="whitespace-nowrap sticky left-0 bg-muted/50 z-10 text-foreground">工区名称</TableHead>
            <TableHead className="whitespace-nowrap sticky left-24 bg-muted/50 z-10 text-foreground">工区编号</TableHead>
            <TableHead className="whitespace-nowrap sticky left-48 bg-muted/50 z-10 text-foreground">工区状态</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">全周期总成本</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">房产总成本（管理期）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">租赁总成本（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">租赁成本（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">租金成本（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">物业成本（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">其他费用（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">『押金/保证金』总金额（本次）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">复原费（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">装修成本（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">顾问服务费（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工程费用（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">家具/固定装置/设备费用（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">运营成本</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">房产部门成本</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">单月总成本（含税）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">单工位成本（工位费用）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">单工位费用（合同工位收费标准）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">单平米成本（元/平米）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">单面积租赁成本（元/平米/月）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">单面积租金（元/平米/月）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">单面积物业费（元/平米/月）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">单面积运营成本（元/平米/月）</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {workzones.map((workzone) => (
            <TableRow key={workzone.id} className="hover:bg-muted/50">
              <TableCell className="whitespace-nowrap sticky left-0 bg-background">
                <button
                  className="text-primary hover:text-primary/80 hover:underline font-medium"
                  onClick={() => onWorkzoneSelect(workzone)}
                >
                  {workzone.name}
                </button>
              </TableCell>
              <TableCell className="whitespace-nowrap sticky left-24 bg-background text-muted-foreground">{workzone.code}</TableCell>
              <TableCell className="whitespace-nowrap sticky left-48 bg-background">
                <Badge variant={
                  workzone.status === '已交付' ? 'default' : 
                  workzone.status === '已退租' ? 'destructive' : 
                  'secondary'
                }>
                  {workzone.status}
                </Badge>
              </TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 600)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 500)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 360)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 300)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 300)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 60)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 10)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 20)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 30)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 156)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 10)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 120)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 36)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 40)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 20)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 10)}万元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round((workzone.area * 10000) / workzone.workstations)}元/月</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round((workzone.area * 11200) / workzone.workstations)}元/月</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(200)}元/月</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(50)}元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(50)}元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(10)}元</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(6.6)}元</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}