import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { WorkzoneData } from '../constants/types';

interface BusinessInfoTabProps {
  workzones: WorkzoneData[];
  onWorkzoneSelect: (workzone: WorkzoneData, defaultTab?: string) => void;
}

export default function BusinessInfoTab({ workzones, onWorkzoneSelect }: BusinessInfoTabProps) {
  return (
    <div className="border border-border rounded-lg overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="whitespace-nowrap sticky left-0 bg-muted/50 z-10 text-foreground">工区名称</TableHead>
            <TableHead className="whitespace-nowrap sticky left-24 bg-muted/50 z-10 text-foreground">工区编号</TableHead>
            <TableHead className="whitespace-nowrap sticky left-48 bg-muted/50 z-10 text-foreground">工区状态</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">职场业务类型</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">职场业务分类</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">最大业务部门</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">TOP3部门</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">1级部门数量</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">特殊业务</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工位总数</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">已分配</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">未分配</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">分配率</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">未来规划方向</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {workzones.map((workzone) => (
            <TableRow key={workzone.id} className="hover:bg-muted/50">
              <TableCell className="whitespace-nowrap sticky left-0 bg-background">
                <button
                  className="text-primary hover:text-primary/80 hover:underline font-medium"
                  onClick={() => onWorkzoneSelect(workzone)}
                >
                  {workzone.name}
                </button>
              </TableCell>
              <TableCell className="whitespace-nowrap sticky left-24 bg-background text-muted-foreground">{workzone.code}</TableCell>
              <TableCell className="whitespace-nowrap sticky left-48 bg-background">
                <Badge variant={
                  workzone.status === '已交付' ? 'default' : 
                  workzone.status === '已退租' ? 'destructive' : 
                  'secondary'
                }>
                  {workzone.status}
                </Badge>
              </TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.businessType === '研发中心' ? '产研' : workzone.businessType === '技术支持' ? '技术支持' : workzone.businessType === '销售支持' ? '销售' : workzone.businessType === '市场营销' ? '市场营销' : workzone.businessType === '运营支持' ? 'BPO' : workzone.businessType === '产品研发' ? '产研' : '其他'}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">综合</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.businessType}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.businessType}、技术部、产品部</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(Math.random() * 5) + 3}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.random() > 0.7 ? '数据处理' : '无'}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.workstations}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.85)}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.15)}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">85%</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '已交付' ? '保留' : workzone.status === '未交付' ? '保留' : '到期退'}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}