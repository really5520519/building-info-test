import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { WorkzoneData } from '../constants/types';

interface BillingInfoTabProps {
  workzones: WorkzoneData[];
  onWorkzoneSelect: (workzone: WorkzoneData, defaultTab?: string) => void;
}

export default function BillingInfoTab({ workzones, onWorkzoneSelect }: BillingInfoTabProps) {
  return (
    <div className="border border-border rounded-lg overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="whitespace-nowrap sticky left-0 bg-muted/50 z-10 text-foreground">工区名称</TableHead>
            <TableHead className="whitespace-nowrap sticky left-24 bg-muted/50 z-10 text-foreground">工区编号</TableHead>
            <TableHead className="whitespace-nowrap sticky left-48 bg-muted/50 z-10 text-foreground">工区状态</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工位服务单价（房产）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">独立空间服务单价（房产）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">房产管理成本</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">1.2升降桌服务单价</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">1.4升降桌服务单价</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">Plus升降桌服务单价</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">工区定价方式</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">定价面积</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">定价工位数</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">独立空间分配面积</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">定价适用期间</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">定价适用期间（租赁合同）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">定价适用期间（装修期）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">定价适用期间（运营期）</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {workzones.map((workzone) => (
            <TableRow key={workzone.id} className="hover:bg-muted/50">
              <TableCell className="whitespace-nowrap sticky left-0 bg-background">
                <button
                  className="text-primary hover:text-primary/80 hover:underline font-medium"
                  onClick={() => onWorkzoneSelect(workzone, 'billing')}
                >
                  {workzone.name}
                </button>
              </TableCell>
              <TableCell className="whitespace-nowrap sticky left-24 bg-background text-muted-foreground">{workzone.code}</TableCell>
              <TableCell className="whitespace-nowrap sticky left-48 bg-background">
                <Badge variant={
                  workzone.status === '已交付' ? 'default' : 
                  workzone.status === '已退租' ? 'destructive' : 
                  'secondary'
                }>
                  {workzone.status}
                </Badge>
              </TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round((workzone.area * 11200) / workzone.workstations)}元/月</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">200元/㎡/月</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">100元/㎡/月</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round((workzone.area * 12000) / workzone.workstations)}元/月</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round((workzone.area * 12800) / workzone.workstations)}元/月</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round((workzone.area * 14000) / workzone.workstations)}元/月</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">按工位定价</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.area}㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.workstations}个</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.16)}㎡</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">2023-2028</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">2023-2028</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">2023.01-2023.03</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">2023.04-2028.01</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}