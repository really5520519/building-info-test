import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { WorkzoneData } from '../constants/types';

interface OperationInfoTabProps {
  workzones: WorkzoneData[];
  onWorkzoneSelect: (workzone: WorkzoneData, defaultTab?: string) => void;
}

export default function OperationInfoTab({ workzones, onWorkzoneSelect }: OperationInfoTabProps) {
  return (
    <div className="border border-border rounded-lg overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="whitespace-nowrap sticky left-0 bg-muted/50 z-10 text-foreground">工区名称</TableHead>
            <TableHead className="whitespace-nowrap sticky left-24 bg-muted/50 z-10 text-foreground">工区编号</TableHead>
            <TableHead className="whitespace-nowrap sticky left-48 bg-muted/50 z-10 text-foreground">工区状态</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否24小时工区</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">停车场</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">停车位数量</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">大小物业</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">餐厅楼层</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">餐位数量</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">供电电源类型</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">空调系统类型</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">空调制冷日期</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">空调供暖日期</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">周末是否有空调</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">可加时的时段</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">空调加时收费标准</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">电梯信息</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">电梯数量（台）-客梯</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">电梯数量（台）-货梯</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">电梯数量（台）-扶梯或其他</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">电梯品牌</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">电梯型号（自建/自持需附参数清单）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">有无电梯机房</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">使用年限（年）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">电梯管理方</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">AP数量</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">网口数量</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">各类机房数量</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">UPS工位数量</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否供餐工区</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否开火工区</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否有健身房</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否行政驻场</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">门禁类型</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">门禁状态</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否物业闸机</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">是否安保人员驻场</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {workzones.map((workzone) => (
            <TableRow key={workzone.id} className="hover:bg-muted/50">
              <TableCell className="whitespace-nowrap sticky left-0 bg-background">
                <button
                  className="text-primary hover:text-primary/80 hover:underline font-medium"
                  onClick={() => onWorkzoneSelect(workzone)}
                >
                  {workzone.name}
                </button>
              </TableCell>
              <TableCell className="whitespace-nowrap sticky left-24 bg-background text-muted-foreground">{workzone.code}</TableCell>
              <TableCell className="whitespace-nowrap sticky left-48 bg-background">
                <Badge variant={
                  workzone.status === '已交付' ? 'default' : 
                  workzone.status === '已退租' ? 'destructive' : 
                  'secondary'
                }>
                  {workzone.status}
                </Badge>
              </TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.is24Hours ? '是' : '否'}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">地下停车场</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}个</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">大物业统一管理</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">1楼</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.5)}个</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">市电+备用发电机</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">中央空调</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">4月1日-10月31日</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">11月1日-3月31日</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">是</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">18:30-22:00</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">10元/小时</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">品牌电梯，定期维护</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.max(1, Math.floor(workzone.physicalFloors / 8))}台</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">1台</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.physicalFloors > 15 ? '2台' : '0台'}</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">某某电梯</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">XX-2000</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">有</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">5年</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">物业公司</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations / 4)}个</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 1.5)}个</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">弱电机房2个，强电机房1个</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.25)}个</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">是</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">否</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">是</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">是</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">刷卡+指纹</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">正常</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">是</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">是</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}