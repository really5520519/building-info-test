import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { WorkzoneData } from '../constants/types';

interface ComplianceInfoTabProps {
  workzones: WorkzoneData[];
  onWorkzoneSelect: (workzone: WorkzoneData, defaultTab?: string) => void;
}

export default function ComplianceInfoTab({ workzones, onWorkzoneSelect }: ComplianceInfoTabProps) {
  return (
    <div className="border border-border rounded-lg overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="whitespace-nowrap sticky left-0 bg-muted/50 z-10 text-foreground">工区名称</TableHead>
            <TableHead className="whitespace-nowrap sticky left-24 bg-muted/50 z-10 text-foreground">工区编号</TableHead>
            <TableHead className="whitespace-nowrap sticky left-48 bg-muted/50 z-10 text-foreground">工区状态</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">消防合规工位数（工区、楼层）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">合规结果</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">楼宇渠道（是否PA政策工区）</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">产权方</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">出租方</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">产权方与出租方关系</TableHead>
            <TableHead className="whitespace-nowrap text-foreground">出租链条</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {workzones.map((workzone) => (
            <TableRow key={workzone.id} className="hover:bg-muted/50">
              <TableCell className="whitespace-nowrap sticky left-0 bg-background">
                <button
                  className="text-primary hover:text-primary/80 hover:underline font-medium"
                  onClick={() => onWorkzoneSelect(workzone)}
                >
                  {workzone.name}
                </button>
              </TableCell>
              <TableCell className="whitespace-nowrap sticky left-24 bg-background text-muted-foreground">{workzone.code}</TableCell>
              <TableCell className="whitespace-nowrap sticky left-48 bg-background">
                <Badge variant={
                  workzone.status === '已交付' ? 'default' : 
                  workzone.status === '已退租' ? 'destructive' : 
                  'secondary'
                }>
                  {workzone.status}
                </Badge>
              </TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.workstations}个</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">合规</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">否</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">某某地产发展有限公司</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">某某地产发展有限公司</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">同一主体</TableCell>
              <TableCell className="whitespace-nowrap text-muted-foreground">直租</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}