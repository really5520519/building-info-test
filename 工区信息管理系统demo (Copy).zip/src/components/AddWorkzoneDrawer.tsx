import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from './ui/sheet';
import { Badge } from './ui/badge';
import { X } from 'lucide-react';

interface AddWorkzoneDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
}

export default function AddWorkzoneDrawer({ isOpen, onClose, onSubmit }: AddWorkzoneDrawerProps) {
  const [formData, setFormData] = useState({
    region: '',
    country: '',
    province: '',
    city: '',
    district: '',
    name: '',
    code: '',
    mainDataCode: '',
    status: '',
    businessType: '',
    workzoneType: '',
    address: '',
    postalCode: '',
    businessDistrict: '',
    buildingLevel: '',
    leaseType: '',
    leaseForm: '',
    isFullLease: '',
    is24Hours: '',
    isHighRise: '',
    specialFunction: '',
    isConfidential: '',
    isSharedWorkspace: '',
    isPark: '',
    buildingCount: '',
    physicalFloors: '',
    elevatorFloors: ''
  });

  const handleSubmit = () => {
    onSubmit(formData);
    onClose();
  };

  const FormField = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className="space-y-2">
      <Label className="text-sm font-medium text-foreground">{label}</Label>
      {children}
    </div>
  );

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="right" className="w-[100vw] overflow-y-auto">
        <SheetHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <SheetTitle className="text-lg font-medium text-foreground">基础信息</SheetTitle>
              <Badge variant="destructive" className="text-xs">非公开</Badge>
            </div>

          </div>
          <SheetDescription className="text-sm text-muted-foreground">
            填写工区基础信息，完成后可进入详情页面进行进一步编辑
          </SheetDescription>
        </SheetHeader>

        <div className="space-y-6 mt-6">
          <div className="grid grid-cols-2 gap-4">
            <FormField label="房产分区">
              <Select value={formData.region} onValueChange={(value) => setFormData({...formData, region: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择房产分区" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="华东大区">华东大区</SelectItem>
                  <SelectItem value="华北大区">华北大区</SelectItem>
                  <SelectItem value="华南大区">华南大区</SelectItem>
                  <SelectItem value="西南大区">西南大区</SelectItem>
                  <SelectItem value="华中大区">华中大区</SelectItem>
                  <SelectItem value="西北大区">西北大区</SelectItem>
                </SelectContent>
              </Select>
            </FormField>

            <FormField label="国家/地区">
              <Select value={formData.country} onValueChange={(value) => setFormData({...formData, country: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择国家/地区" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="中国">中国</SelectItem>
                  <SelectItem value="美国">美国</SelectItem>
                  <SelectItem value="新加坡">新加坡</SelectItem>
                </SelectContent>
              </Select>
            </FormField>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <FormField label="省/州">
              <Select value={formData.province} onValueChange={(value) => setFormData({...formData, province: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择省/州" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="上海市">上海市</SelectItem>
                  <SelectItem value="北京市">北京市</SelectItem>
                  <SelectItem value="广东省">广东省</SelectItem>
                  <SelectItem value="浙江省">浙江省</SelectItem>
                  <SelectItem value="江苏省">江苏省</SelectItem>
                </SelectContent>
              </Select>
            </FormField>

            <FormField label="城市">
              <Select value={formData.city} onValueChange={(value) => setFormData({...formData, city: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择城市" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="上海市">上海市</SelectItem>
                  <SelectItem value="北京市">北京市</SelectItem>
                  <SelectItem value="深圳市">深圳市</SelectItem>
                  <SelectItem value="杭州市">杭州市</SelectItem>
                  <SelectItem value="南京市">南京市</SelectItem>
                </SelectContent>
              </Select>
            </FormField>
          </div>

          <FormField label="区县">
            <Select value={formData.district} onValueChange={(value) => setFormData({...formData, district: value})}>
              <SelectTrigger>
                <SelectValue placeholder="选择区县" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="浦东新区">浦东新区</SelectItem>
                <SelectItem value="黄浦区">黄浦区</SelectItem>
                <SelectItem value="静安区">静安区</SelectItem>
                <SelectItem value="徐汇区">徐汇区</SelectItem>
              </SelectContent>
            </Select>
          </FormField>

          <div className="grid grid-cols-2 gap-4">
            <FormField label="工区名称">
              <Input 
                value={formData.name} 
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="输入工区名称" 
              />
            </FormField>

            <FormField label="工区编号">
              <Input 
                value={formData.code} 
                onChange={(e) => setFormData({...formData, code: e.target.value})}
                placeholder="输入工区编号" 
              />
            </FormField>
          </div>

          <FormField label="工区主数据编码">
            <Input 
              value={formData.mainDataCode} 
              onChange={(e) => setFormData({...formData, mainDataCode: e.target.value})}
              placeholder="输入主数据编码" 
            />
          </FormField>

          <div className="grid grid-cols-2 gap-4">
            <FormField label="工区状态">
              <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择工区状态" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="设计中">设计中</SelectItem>
                  <SelectItem value="装修中">装修中</SelectItem>
                  <SelectItem value="已交付">已交付</SelectItem>
                  <SelectItem value="已退租">已退租</SelectItem>
                </SelectContent>
              </Select>
            </FormField>

            <FormField label="业务类型">
              <Select value={formData.businessType} onValueChange={(value) => setFormData({...formData, businessType: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择业务类型" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="研发中心">研发中心</SelectItem>
                  <SelectItem value="技术支持">技术支持</SelectItem>
                  <SelectItem value="销售支持">销售支持</SelectItem>
                  <SelectItem value="市场营销">市场营销</SelectItem>
                </SelectContent>
              </Select>
            </FormField>
          </div>

          <FormField label="工区类型">
            <Select value={formData.workzoneType} onValueChange={(value) => setFormData({...formData, workzoneType: value})}>
              <SelectTrigger>
                <SelectValue placeholder="选择工区类型" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="标准办公">标准办公</SelectItem>
                <SelectItem value="联合办公">联合办公</SelectItem>
                <SelectItem value="创新办公">创新办公</SelectItem>
              </SelectContent>
            </Select>
          </FormField>

          <FormField label="合同地址">
            <Input 
              value={formData.address} 
              onChange={(e) => setFormData({...formData, address: e.target.value})}
              placeholder="输入合同地址" 
            />
          </FormField>

          <div className="grid grid-cols-2 gap-4">
            <FormField label="邮政编码">
              <Input 
                value={formData.postalCode} 
                onChange={(e) => setFormData({...formData, postalCode: e.target.value})}
                placeholder="输入邮政编码" 
              />
            </FormField>

            <FormField label="办公室所属商圈/区位">
              <Input 
                value={formData.businessDistrict} 
                onChange={(e) => setFormData({...formData, businessDistrict: e.target.value})}
                placeholder="输入商圈/区位" 
              />
            </FormField>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <FormField label="办公楼等级标准">
              <Select value={formData.buildingLevel} onValueChange={(value) => setFormData({...formData, buildingLevel: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择等级标准" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A级">A级</SelectItem>
                  <SelectItem value="B+级">B+级</SelectItem>
                  <SelectItem value="B级">B级</SelectItem>
                  <SelectItem value="C级">C级</SelectItem>
                </SelectContent>
              </Select>
            </FormField>

            <FormField label="租赁类型">
              <Select value={formData.leaseType} onValueChange={(value) => setFormData({...formData, leaseType: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择租赁类型" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="租赁">租赁</SelectItem>
                  <SelectItem value="自有">自有</SelectItem>
                  <SelectItem value="合作">合作</SelectItem>
                </SelectContent>
              </Select>
            </FormField>
          </div>

          <FormField label="租赁形式">
            <Select value={formData.leaseForm} onValueChange={(value) => setFormData({...formData, leaseForm: value})}>
              <SelectTrigger>
                <SelectValue placeholder="选择租赁形式" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="整租">整租</SelectItem>
                <SelectItem value="分租">分租</SelectItem>
                <SelectItem value="联合租赁">联合租赁</SelectItem>
              </SelectContent>
            </Select>
          </FormField>

          <div className="grid grid-cols-2 gap-4">
            <FormField label="是否整租">
              <Select value={formData.isFullLease} onValueChange={(value) => setFormData({...formData, isFullLease: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="是">是</SelectItem>
                  <SelectItem value="否">否</SelectItem>
                </SelectContent>
              </Select>
            </FormField>

            <FormField label="是否24h职场">
              <Select value={formData.is24Hours} onValueChange={(value) => setFormData({...formData, is24Hours: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="是">是</SelectItem>
                  <SelectItem value="否">否</SelectItem>
                </SelectContent>
              </Select>
            </FormField>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <FormField label="是否高层建筑">
              <Select value={formData.isHighRise} onValueChange={(value) => setFormData({...formData, isHighRise: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="是">是</SelectItem>
                  <SelectItem value="否">否</SelectItem>
                </SelectContent>
              </Select>
            </FormField>

            <FormField label="职场特殊功能/用途">
              <Input 
                value={formData.specialFunction} 
                onChange={(e) => setFormData({...formData, specialFunction: e.target.value})}
                placeholder="输入特殊功能" 
              />
            </FormField>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <FormField label="是否保密职场">
              <Select value={formData.isConfidential} onValueChange={(value) => setFormData({...formData, isConfidential: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="是">是</SelectItem>
                  <SelectItem value="否">否</SelectItem>
                </SelectContent>
              </Select>
            </FormField>

            <FormField label="是否共享工位职场">
              <Select value={formData.isSharedWorkspace} onValueChange={(value) => setFormData({...formData, isSharedWorkspace: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="选择" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="是">是</SelectItem>
                  <SelectItem value="否">否</SelectItem>
                </SelectContent>
              </Select>
            </FormField>
          </div>

          <FormField label="是否园区">
            <Select value={formData.isPark} onValueChange={(value) => setFormData({...formData, isPark: value})}>
              <SelectTrigger>
                <SelectValue placeholder="选择" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="是">是</SelectItem>
                <SelectItem value="否">否</SelectItem>
              </SelectContent>
            </Select>
          </FormField>

          <div className="grid grid-cols-3 gap-4">
            <FormField label="楼栋数">
              <Input 
                type="number"
                value={formData.buildingCount} 
                onChange={(e) => setFormData({...formData, buildingCount: e.target.value})}
                placeholder="输入楼栋数" 
              />
            </FormField>

            <FormField label="物理楼层数量">
              <Input 
                type="number"
                value={formData.physicalFloors} 
                onChange={(e) => setFormData({...formData, physicalFloors: e.target.value})}
                placeholder="输入楼层数" 
              />
            </FormField>

            <FormField label="电梯楼层数量">
              <Input 
                type="number"
                value={formData.elevatorFloors} 
                onChange={(e) => setFormData({...formData, elevatorFloors: e.target.value})}
                placeholder="输入电梯楼层数" 
              />
            </FormField>
          </div>
        </div>

        <div className="flex justify-end mt-8 pt-6 border-t border-border">
          <Button onClick={handleSubmit} className="bg-primary hover:bg-primary/90 text-primary-foreground">
            下一步
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}