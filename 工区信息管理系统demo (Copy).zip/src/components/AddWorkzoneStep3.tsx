import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Textarea } from './ui/textarea';
import { ArrowLeft, Sparkles, Upload, Link, FileText, ExternalLink, Plus, Edit, Trash2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { Badge } from './ui/badge';

interface AddWorkzoneStep3Props {
  onBack: () => void;
  onSubmit: (data: any) => void;
  onSaveDraft?: (data: any) => void;
  initialData?: any;
}

export default function AddWorkzoneStep3({ onBack, onSubmit, onSaveDraft, initialData }: AddWorkzoneStep3Props) {
  const [isPublic, setIsPublic] = useState(true);
  const [showAIDialog, setShowAIDialog] = useState(false);
  const [textType, setTextType] = useState('paste');
  const [aiInputText, setAiInputText] = useState('');
  const [aiInputLink, setAiInputLink] = useState('');
  const [aiInputFile, setAiInputFile] = useState<File | null>(null);

  // 模拟合同数据
  const contractData = [
    {
      id: 'CT-001',
      name: '上海浦东办公楼租赁合同',
      status: '已签约',
      term: '2024-01-01 至 2026-12-31',
      area: '2,500㎡',
      floors: '15-17层',
      estimatedWorkstations: '180个',
      ourEntity: '上海科技有限公司',
      counterparty: '浦东置业集团',
      totalAmount: '¥15,600,000'
    },
    {
      id: 'CT-002',
      name: '会议室补充租赁协议',
      status: '执行中',
      term: '2024-06-01 至 2025-05-31',
      area: '200㎡',
      floors: '16层',
      estimatedWorkstations: '0个',
      ourEntity: '上海科技有限公司',
      counterparty: '浦东置业集团',
      totalAmount: '¥800,000'
    }
  ];

  // 模拟项目数据
  const projectData = [
    {
      id: 'PJ-001',
      name: '浦东研发中心装修改造项目',
      status: '进行中',
      floor: '15-17层',
      startTime: '2024-01-15',
      endTime: '2024-06-30',
      completionTime: '2024-06-15',
      expectedMoveIn: '2024-07-01',
      moveStatus: '待搬迁'
    },
    {
      id: 'PJ-002',
      name: '智能化办公系统部署',
      status: '已完成',
      floor: '15层',
      startTime: '2024-03-01',
      endTime: '2024-04-30',
      completionTime: '2024-04-28',
      expectedMoveIn: '2024-05-01',
      moveStatus: '已完成'
    }
  ];

  // 模拟楼层运营数据
  const floorData = [
    {
      floor: '15层',
      purpose: '研发办公区',
      area: '800㎡',
      workstations: '60个',
      collaborationArea: '120㎡',
      supportArea: '80㎡',
      department: '产品研发部'
    },
    {
      floor: '16层',
      purpose: '管理办公区',
      area: '850㎡',
      workstations: '65个',
      collaborationArea: '100㎡',
      supportArea: '150㎡',
      department: '管理中心、财务部'
    },
    {
      floor: '17层',
      purpose: '销售办公区',
      area: '850㎡',
      workstations: '70个',
      collaborationArea: '150㎡',
      supportArea: '100㎡',
      department: '销售部、市场部'
    }
  ];

  const handleSubmit = () => {
    const combinedData = {
      ...initialData,
      contracts: contractData,
      projects: projectData,
      floors: floorData,
      isPublic
    };
    onSubmit(combinedData);
  };

  const handleSaveDraft = () => {
    const draftData = {
      ...initialData,
      contracts: contractData,
      projects: projectData,
      floors: floorData,
      isPublic,
      isDraft: true
    };
    if (onSaveDraft) {
      onSaveDraft(draftData);
    }
    toast.success('草稿已保存');
  };

  const handleAIFill = () => {
    setShowAIDialog(true);
  };

  const handleParseKeywords = () => {
    console.log('解析关键词:', { textType, aiInputText, aiInputLink, aiInputFile });
    
    setTimeout(() => {
      setShowAIDialog(false);
      toast.success('已完成');
      
      setAiInputText('');
      setAiInputLink('');
      setAiInputFile(null);
      setTextType('paste');
    }, 1000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setAiInputFile(file);
    }
  };

  const handleEditContract = (contractId: string) => {
    console.log('编辑合同:', contractId);
    toast.success('编辑合同功能开发中');
  };

  const handleDeleteContract = (contractId: string) => {
    console.log('删除合同:', contractId);
    toast.success('删除合同功能开发中');
  };

  const handleEditProject = (projectId: string) => {
    console.log('编辑项目:', projectId);
    toast.success('编辑项目功能开发中');
  };

  const handleDeleteProject = (projectId: string) => {
    console.log('删除项目:', projectId);
    toast.success('删除项目功能开发中');
  };

  const handleEditFloor = (floor: string) => {
    console.log('编辑楼层:', floor);
    toast.success('编辑楼层功能开发中');
  };

  const handleDeleteFloor = (floor: string) => {
    console.log('删除楼层:', floor);
    toast.success('删除楼层功能开发中');
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      '已签约': 'bg-green-100 text-green-800',
      '执行中': 'bg-blue-100 text-blue-800',
      '进行中': 'bg-yellow-100 text-yellow-800',
      '已完成': 'bg-green-100 text-green-800',
      '待搬迁': 'bg-orange-100 text-orange-800'
    };
    
    return (
      <Badge className={`${statusConfig[status as keyof typeof statusConfig] || 'bg-gray-100 text-gray-800'}`}>
        {status}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      {/* 头部导航 */}
      <div className="bg-card border-b border-border px-6 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={onBack} className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4" />
              返回
            </Button>
            <div className="flex items-center gap-3">
              <h1 className="text-lg font-medium text-foreground">房产信息</h1>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleAIFill}
                className="flex items-center gap-2 text-primary hover:text-primary hover:bg-primary/5"
              >
                <Sparkles className="w-4 h-4" />
                AI快速填写
              </Button>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">
                  {isPublic ? '公开' : '不公开'}
                </span>
                <Switch
                  checked={isPublic}
                  onCheckedChange={setIsPublic}
                  className={isPublic 
                    ? "data-[state=checked]:bg-primary" 
                    : "data-[state=unchecked]:bg-destructive"
                  }
                />
              </div>
            </div>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          查看和管理工区相关的合同、项目和楼层运营信息
        </p>
      </div>

      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          {/* 填写步骤指示器 */}
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center space-x-8">
              {/* 步骤1 - 基本信息 */}
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium">
                  ✓
                </div>
                <span className="text-muted-foreground">基本信息</span>
              </div>
              
              {/* 连接线1 */}
              <div className="w-16 h-px bg-primary"></div>
              
              {/* 步骤2 - 业务信息 */}
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium">
                  ✓
                </div>
                <span className="text-muted-foreground">业务信息</span>
              </div>
              
              {/* 连接线2 */}
              <div className="w-16 h-px bg-primary"></div>
              
              {/* 步骤3 - 房产信息 */}
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium">
                  3
                </div>
                <span className="text-primary font-medium">房产信息</span>
              </div>
            </div>
          </div>
          
          <div className="space-y-8">
            {/* 租赁信息*/}
            <div className="border border-border rounded-lg p-6 bg-card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-foreground">租赁信息</h3>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  添加合同
                </Button>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">合同编号</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">名称</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">状态</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">租期</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">面积</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">楼层数</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">预估工位数</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">我方主体</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">对方主体</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">总金额</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {contractData.map((contract) => (
                      <tr key={contract.id} className="border-b border-border hover:bg-muted/50">
                        <td className="p-3 text-sm">{contract.id}</td>
                        <td className="p-3 text-sm">{contract.name}</td>
                        <td className="p-3">{getStatusBadge(contract.status)}</td>
                        <td className="p-3 text-sm">{contract.term}</td>
                        <td className="p-3 text-sm">{contract.area}</td>
                        <td className="p-3 text-sm">{contract.floors}</td>
                        <td className="p-3 text-sm">{contract.estimatedWorkstations}</td>
                        <td className="p-3 text-sm">{contract.ourEntity}</td>
                        <td className="p-3 text-sm">{contract.counterparty}</td>
                        <td className="p-3 text-sm font-medium">{contract.totalAmount}</td>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <Button variant="ghost" size="sm" className="flex items-center gap-1 text-primary">
                              查看详情
                              <ExternalLink className="w-3 h-3" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleEditContract(contract.id)}
                              className="flex items-center gap-1 text-blue-600 hover:text-blue-700"
                            >
                              编辑
                              <Edit className="w-3 h-3" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleDeleteContract(contract.id)}
                              className="flex items-center gap-1 text-blue-600 hover:text-blue-700"
                            >
                              删除
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 项目信息 */}
            <div className="border border-border rounded-lg p-6 bg-card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-foreground">项目信息</h3>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  添加项目
                </Button>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">项目编号</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">名称</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">状态</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">楼层</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">启动时间</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">结束时间</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">竣工时间</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">预计入驻时间</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">搬家状态</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {projectData.map((project) => (
                      <tr key={project.id} className="border-b border-border hover:bg-muted/50">
                        <td className="p-3 text-sm">{project.id}</td>
                        <td className="p-3 text-sm">{project.name}</td>
                        <td className="p-3">{getStatusBadge(project.status)}</td>
                        <td className="p-3 text-sm">{project.floor}</td>
                        <td className="p-3 text-sm">{project.startTime}</td>
                        <td className="p-3 text-sm">{project.endTime}</td>
                        <td className="p-3 text-sm">{project.completionTime}</td>
                        <td className="p-3 text-sm">{project.expectedMoveIn}</td>
                        <td className="p-3">{getStatusBadge(project.moveStatus)}</td>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <Button variant="ghost" size="sm" className="flex items-center gap-1 text-primary">
                              查看详情
                              <ExternalLink className="w-3 h-3" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleEditProject(project.id)}
                              className="flex items-center gap-1 text-blue-600 hover:text-blue-700"
                            >
                              编辑
                              <Edit className="w-3 h-3" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleDeleteProject(project.id)}
                              className="flex items-center gap-1 text-blue-600 hover:text-blue-700"
                            >
                              删除
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 运营信息（楼层列表） */}
            <div className="border border-border rounded-lg p-6 bg-card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-foreground">运营信息</h3>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  添加楼层
                </Button>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">楼层</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">用途</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">面积</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">工位数</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">协作区面积</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">配套面积</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">业务部门</th>
                      <th className="text-left p-3 font-medium text-foreground whitespace-nowrap">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {floorData.map((floor) => (
                      <tr key={floor.floor} className="border-b border-border hover:bg-muted/50">
                        <td className="p-3 text-sm font-medium">{floor.floor}</td>
                        <td className="p-3 text-sm">{floor.purpose}</td>
                        <td className="p-3 text-sm">{floor.area}</td>
                        <td className="p-3 text-sm">{floor.workstations}</td>
                        <td className="p-3 text-sm">{floor.collaborationArea}</td>
                        <td className="p-3 text-sm">{floor.supportArea}</td>
                        <td className="p-3 text-sm">{floor.department}</td>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <Button variant="ghost" size="sm" className="flex items-center gap-1 text-primary">
                              查看详情
                              <ExternalLink className="w-3 h-3" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleEditFloor(floor.floor)}
                              className="flex items-center gap-1 text-blue-600 hover:text-blue-700"
                            >
                              编辑
                              <Edit className="w-3 h-3" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleDeleteFloor(floor.floor)}
                              className="flex items-center gap-1 text-blue-600 hover:text-blue-700"
                            >
                              删除
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 底部按钮 */}
            <div className="flex justify-between gap-3 pt-6">
              <Button 
                variant="outline" 
                onClick={onBack}
                className="text-muted-foreground hover:text-foreground"
              >
                上一步
              </Button>
              
              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  onClick={handleSaveDraft}
                  className="text-muted-foreground hover:text-foreground"
                >
                  存为草稿
                </Button>
                <Button onClick={handleSubmit} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  完成创建
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI快速填写弹窗 */}
      <Dialog open={showAIDialog} onOpenChange={setShowAIDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>添加文本到当前页面</DialogTitle>
            <DialogDescription>
              选择文本输入方式，AI将帮助您解析关键词并快速填写表单。
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <div className="space-y-4">
              <Label>文本类型</Label>
              <RadioGroup value={textType} onValueChange={setTextType} className="grid grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="link" id="link" />
                  <Label htmlFor="link" className={`flex items-center gap-2 cursor-pointer ${textType === 'link' ? 'text-primary' : ''}`}>
                    <Link className="w-4 h-4" />
                    飞书文档链接
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="upload" id="upload" />
                  <Label htmlFor="upload" className={`flex items-center gap-2 cursor-pointer ${textType === 'upload' ? 'text-primary' : ''}`}>
                    <Upload className="w-4 h-4" />
                    附件上传
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="paste" id="paste" />
                  <Label htmlFor="paste" className={`flex items-center gap-2 cursor-pointer ${textType === 'paste' ? 'text-primary' : ''}`}>
                    <FileText className="w-4 h-4" />
                    文本粘贴
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              {textType === 'link' && (
                <div className="space-y-2">
                  <Label>飞书文档链接</Label>
                  <Input
                    value={aiInputLink}
                    onChange={(e) => setAiInputLink(e.target.value)}
                    placeholder="请粘贴飞书文档链接"
                  />
                </div>
              )}

              {textType === 'upload' && (
                <div className="space-y-2">
                  <Label>上传附件</Label>
                  <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                    <input
                      type="file"
                      id="file-upload"
                      className="hidden"
                      onChange={handleFileUpload}
                      accept=".pdf,.doc,.docx,.txt"
                    />
                    <label htmlFor="file-upload" className="cursor-pointer">
                      <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-muted-foreground">
                        {aiInputFile ? aiInputFile.name : '点击上传文件或拖拽文件到此处'}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        支持 PDF、Word、文本文件
                      </p>
                    </label>
                  </div>
                </div>
              )}

              {textType === 'paste' && (
                <div className="space-y-2">
                  <Label>文本内容</Label>
                  <Textarea
                    value={aiInputText}
                    onChange={(e) => setAiInputText(e.target.value)}
                    placeholder="请粘贴或输入文本内容..."
                    rows={6}
                  />
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-border">
            <Button 
              onClick={handleParseKeywords}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
              disabled={
                (textType === 'paste' && !aiInputText.trim()) ||
                (textType === 'link' && !aiInputLink.trim()) ||
                (textType === 'upload' && !aiInputFile)
              }
            >
              解析关键词
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}