import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { ArrowLeft, Download, Eye, Upload, FileText, FileImage, File, X } from 'lucide-react';
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from './ui/pagination';

interface RelatedFilesProps {
  workzone: any;
  onBack: () => void;
}

const mockFiles = [
  {
    id: '1',
    name: '租赁合同-上海浦东工区.pdf',
    type: '合同文件',
    status: '已审核',
    uploader: '张三',
    updateDate: '2024-01-15',
    size: '2.5MB',
    icon: FileText
  },
  {
    id: '2',
    name: '装修设计图纸.dwg',
    type: '设计图纸',
    status: '审核中',
    uploader: '李四',
    updateDate: '2024-01-14',
    size: '15.8MB',
    icon: FileImage
  },
  {
    id: '3',
    name: '消防验收报告.pdf',
    type: '验收文件',
    status: '已审核',
    uploader: '王五',
    updateDate: '2024-01-13',
    size: '4.2MB',
    icon: FileText
  },
  {
    id: '4',
    name: '物业管理协议.docx',
    type: '协议文件',
    status: '已审核',
    uploader: '赵六',
    updateDate: '2024-01-12',
    size: '1.8MB',
    icon: FileText
  },
  {
    id: '5',
    name: '工区现场照片.zip',
    type: '现场资料',
    status: '已审核',
    uploader: '钱七',
    updateDate: '2024-01-11',
    size: '25.6MB',
    icon: FileImage
  },
  {
    id: '6',
    name: '环保检测报告.pdf',
    type: '检测报告',
    status: '已审核',
    uploader: '孙八',
    updateDate: '2024-01-10',
    size: '3.1MB',
    icon: FileText
  },
  {
    id: '7',
    name: '设备清单.xlsx',
    type: '清单文件',
    status: '草稿',
    uploader: '周九',
    updateDate: '2024-01-09',
    size: '0.8MB',
    icon: File
  },
  {
    id: '8',
    name: '安全管理制度.pdf',
    type: '制度文件',
    status: '已审核',
    uploader: '吴十',
    updateDate: '2024-01-08',
    size: '2.2MB',
    icon: FileText
  }
];

export default function RelatedFiles({ workzone, onBack }: RelatedFilesProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [uploadFormData, setUploadFormData] = useState({
    fileName: '',
    fileType: '',
    uploader: '',
    description: '',
    selectedFile: null as File | null
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case '已审核':
        return 'default';
      case '审核中':
        return 'secondary';
      case '草稿':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  const totalPages = Math.ceil(mockFiles.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const currentFiles = mockFiles.slice(startIndex, startIndex + pageSize);

  const handleSelectFile = (fileId: string) => {
    setSelectedFiles(prev =>
      prev.includes(fileId)
        ? prev.filter(id => id !== fileId)
        : [...prev, fileId]
    );
  };

  const handleSelectAll = () => {
    if (selectedFiles.length === currentFiles.length) {
      setSelectedFiles([]);
    } else {
      setSelectedFiles(currentFiles.map(file => file.id));
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadFormData(prev => ({
        ...prev,
        selectedFile: file,
        fileName: file.name
      }));
    }
  };

  const handleUploadSubmit = () => {
    if (!uploadFormData.selectedFile || !uploadFormData.fileType || !uploadFormData.uploader) {
      alert('请填写所有必填字段');
      return;
    }

    // 这里处理文件上传逻辑
    console.log('上传文件:', uploadFormData);
    
    // 重置表单
    setUploadFormData({
      fileName: '',
      fileType: '',
      uploader: '',
      description: '',
      selectedFile: null
    });
    
    // 关闭弹窗
    setIsUploadDialogOpen(false);
    
    // 显示成功消息
    alert('文件上传成功！');
  };

  const resetUploadForm = () => {
    setUploadFormData({
      fileName: '',
      fileType: '',
      uploader: '',
      description: '',
      selectedFile: null
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* 头部 */}
      <div className="bg-card border-b border-border px-6 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={onBack} className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4" />
              返回
            </Button>
            <div>
              <h1 className="text-lg font-medium text-foreground">相关文件 - {workzone?.name}</h1>
              <p className="text-sm text-muted-foreground">工区相关的所有文件资料</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
              <DialogTrigger asChild>
                <Button 
                  className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <Upload className="w-4 h-4" />
                  上传文件
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle className="flex items-center justify-between">
                    <span>上传文件</span>
                    <button
                      className="h-6 w-6 p-0 hover:bg-accent hover:text-accent-foreground rounded-md transition-colors flex items-center justify-center"
                      onClick={() => {
                        setIsUploadDialogOpen(false);
                        resetUploadForm();
                      }}
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </DialogTitle>
                </DialogHeader>
                
                <div className="space-y-4 pt-4">
                  {/* 文件选择 */}
                  <div className="space-y-2">
                    <Label htmlFor="file-upload">选择文件 *</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="file-upload"
                        type="file"
                        onChange={handleFileSelect}
                        className="flex-1"
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg,.zip,.dwg"
                      />
                    </div>
                    {uploadFormData.selectedFile && (
                      <div className="text-sm text-muted-foreground">
                        已选择: {uploadFormData.selectedFile.name}
                      </div>
                    )}
                  </div>

                  {/* 文件名 */}
                  <div className="space-y-2">
                    <Label htmlFor="file-name">文件名 *</Label>
                    <Input
                      id="file-name"
                      value={uploadFormData.fileName}
                      onChange={(e) => setUploadFormData(prev => ({...prev, fileName: e.target.value}))}
                      placeholder="请输入文件名"
                    />
                  </div>

                  {/* 文件类型 */}
                  <div className="space-y-2">
                    <Label htmlFor="file-type">文件类型 *</Label>
                    <Select value={uploadFormData.fileType} onValueChange={(value) => setUploadFormData(prev => ({...prev, fileType: value}))}>
                      <SelectTrigger>
                        <SelectValue placeholder="请选择文件类型" />
                      </SelectTrigger>
                      <SelectContent className="border border-border bg-card">
                        <SelectItem value="合同文件">合同文件</SelectItem>
                        <SelectItem value="设计图纸">设计图纸</SelectItem>
                        <SelectItem value="验收文件">验收文件</SelectItem>
                        <SelectItem value="协议文件">协议文件</SelectItem>
                        <SelectItem value="现场资料">现场资料</SelectItem>
                        <SelectItem value="检测报告">检测报告</SelectItem>
                        <SelectItem value="清单文件">清单文件</SelectItem>
                        <SelectItem value="制度文件">制度文件</SelectItem>
                        <SelectItem value="其他">其他</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* 上传人 */}
                  <div className="space-y-2">
                    <Label htmlFor="uploader">上传人 *</Label>
                    <Input
                      id="uploader"
                      value={uploadFormData.uploader}
                      onChange={(e) => setUploadFormData(prev => ({...prev, uploader: e.target.value}))}
                      placeholder="请输入上传人姓名"
                    />
                  </div>

                  {/* 上传信息 */}
                  <div className="space-y-2">
                    <Label htmlFor="description">文件描述</Label>
                    <Textarea
                      id="description"
                      value={uploadFormData.description}
                      onChange={(e) => setUploadFormData(prev => ({...prev, description: e.target.value}))}
                      placeholder="请输入文件描述信息（可选）"
                      rows={3}
                    />
                  </div>

                  {/* 上传按钮 */}
                  <div className="flex justify-end gap-2 pt-4">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsUploadDialogOpen(false);
                        resetUploadForm();
                      }}
                    >
                      取消
                    </Button>
                    <Button
                      onClick={handleUploadSubmit}
                      className="bg-primary hover:bg-primary/90 text-primary-foreground"
                      disabled={!uploadFormData.selectedFile || !uploadFormData.fileType || !uploadFormData.uploader}
                    >
                      上传文件
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            {selectedFiles.length > 0 && (
              <Button variant="outline" className="flex items-center gap-2">
                <Download className="w-4 h-4" />
                批量下载 ({selectedFiles.length})
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="p-6">
        <Card className="p-6 border border-border">
          {/* 文件统计 */}
          <div className="mb-6">
            <div className="grid grid-cols-4 gap-4">
              <Card className="p-4 bg-primary/5 border border-primary/20">
                <div className="text-center">
                  <div className="text-2xl font-medium text-primary">{mockFiles.length}</div>
                  <div className="text-sm text-muted-foreground">总文件数</div>
                </div>
              </Card>
              <Card className="p-4 bg-green-50 border border-green-200">
                <div className="text-center">
                  <div className="text-2xl font-medium text-green-700">
                    {mockFiles.filter(f => f.status === '已审核').length}
                  </div>
                  <div className="text-sm text-muted-foreground">已审核</div>
                </div>
              </Card>
              <Card className="p-4 bg-yellow-50 border border-yellow-200">
                <div className="text-center">
                  <div className="text-2xl font-medium text-yellow-700">
                    {mockFiles.filter(f => f.status === '审核中').length}
                  </div>
                  <div className="text-sm text-muted-foreground">审核中</div>
                </div>
              </Card>
              <Card className="p-4 bg-gray-50 border border-gray-200">
                <div className="text-center">
                  <div className="text-2xl font-medium text-gray-700">
                    {(mockFiles.reduce((sum, f) => sum + parseFloat(f.size), 0)).toFixed(1)}MB
                  </div>
                  <div className="text-sm text-muted-foreground">总大小</div>
                </div>
              </Card>
            </div>
          </div>

          {/* 文件列表 */}
          <div className="border border-border rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="w-12">
                    <input
                      type="checkbox"
                      checked={selectedFiles.length === currentFiles.length && currentFiles.length > 0}
                      onChange={handleSelectAll}
                      className="rounded"
                    />
                  </TableHead>
                  <TableHead className="text-foreground">文件名</TableHead>
                  <TableHead className="text-foreground">类型</TableHead>
                  <TableHead className="text-foreground">状态</TableHead>
                  <TableHead className="text-foreground">上传人</TableHead>
                  <TableHead className="text-foreground">更新日期</TableHead>
                  <TableHead className="text-foreground">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {currentFiles.map((file) => {
                  const IconComponent = file.icon;
                  return (
                    <TableRow key={file.id} className="hover:bg-muted/50">
                      <TableCell>
                        <input
                          type="checkbox"
                          checked={selectedFiles.includes(file.id)}
                          onChange={() => handleSelectFile(file.id)}
                          className="rounded"
                        />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <IconComponent className="w-4 h-4 text-muted-foreground" />
                          <div>
                            <div className="font-medium text-foreground">{file.name}</div>
                            <div className="text-xs text-muted-foreground">{file.size}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-muted-foreground border-border">{file.type}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusColor(file.status)}>
                          {file.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{file.uploader}</TableCell>
                      <TableCell className="text-muted-foreground">{file.updateDate}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-8 w-8 p-0 hover:bg-primary/10"
                            title="查看"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-8 w-8 p-0 hover:bg-primary/10"
                            title="下载"
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>

          {/* 分页 */}
          <div className="flex items-center justify-between mt-4">
            <div className="text-sm text-muted-foreground whitespace-nowrap">
              显示 {startIndex + 1}-{Math.min(startIndex + pageSize, mockFiles.length)} 共 {mockFiles.length} 条
            </div>
            
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      if (currentPage > 1) setCurrentPage(currentPage - 1);
                    }}
                    className={currentPage <= 1 ? 'pointer-events-none opacity-50' : ''}
                  />
                </PaginationItem>
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const page = i + 1;
                  return (
                    <PaginationItem key={page}>
                      <PaginationLink
                        href="#"
                        isActive={page === currentPage}
                        onClick={(e) => {
                          e.preventDefault();
                          setCurrentPage(page);
                        }}
                      >
                        {page}
                      </PaginationLink>
                    </PaginationItem>
                  );
                })}
                <PaginationItem>
                  <PaginationNext 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                    }}
                    className={currentPage >= totalPages ? 'pointer-events-none opacity-50' : ''}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </div>
        </Card>
      </div>
    </div>
  );
}