import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { ArrowLeft, Download, Eye, FileText, Calendar, DollarSign } from 'lucide-react';
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from './ui/pagination';

interface ContractInfoProps {
  workzone: any;
  onBack: () => void;
}

const mockContracts = [
  {
    id: '1',
    name: '上海浦东工区租赁合同',
    type: '租赁合同',
    status: '生效中',
    contractNumber: 'ZL-2023-001',
    party: '某某地产发展有限公司',
    signDate: '2023-01-01',
    startDate: '2023-01-01',
    endDate: '2028-01-01',
    amount: '1,500万元',
    area: '3,000㎡',
    unitPrice: '8.2元/㎡/天'
  },
  {
    id: '2',
    name: '物业管理服务协议',
    type: '物业合同',
    status: '生效中',
    contractNumber: 'WY-2023-001',
    party: '某某物业管理有限公司',
    signDate: '2023-01-15',
    startDate: '2023-02-01',
    endDate: '2028-01-31',
    amount: '300万元',
    area: '3,000㎡',
    unitPrice: '50元/㎡/月'
  },
  {
    id: '3',
    name: '装修工程合同',
    type: '装修合同',
    status: '已完成',
    contractNumber: 'ZX-2023-001',
    party: '某某装饰工程有限公司',
    signDate: '2022-12-01',
    startDate: '2023-01-01',
    endDate: '2023-03-31',
    amount: '468万元',
    area: '3,000㎡',
    unitPrice: '1,560元/㎡'
  },
  {
    id: '4',
    name: '设备租赁合同',
    type: '设备合同',
    status: '生效中',
    contractNumber: 'SB-2023-001',
    party: '某某设备租赁有限公司',
    signDate: '2023-02-15',
    startDate: '2023-03-01',
    endDate: '2026-02-28',
    amount: '120万元',
    area: '-',
    unitPrice: '-'
  },
  {
    id: '5',
    name: '停车位租赁协议',
    type: '停车合同',
    status: '生效中',
    contractNumber: 'TC-2023-001',
    party: '某某地产发展有限公司',
    signDate: '2023-03-01',
    startDate: '2023-04-01',
    endDate: '2028-01-01',
    amount: '60万元',
    area: '-',
    unitPrice: '500元/位/月'
  }
];

export default function ContractInfo({ workzone, onBack }: ContractInfoProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [selectedContracts, setSelectedContracts] = useState<string[]>([]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case '生效中':
        return 'default';
      case '已完成':
        return 'secondary';
      case '已终止':
        return 'destructive';
      case '待签署':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  const totalPages = Math.ceil(mockContracts.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const currentContracts = mockContracts.slice(startIndex, startIndex + pageSize);

  const handleSelectContract = (contractId: string) => {
    setSelectedContracts(prev =>
      prev.includes(contractId)
        ? prev.filter(id => id !== contractId)
        : [...prev, contractId]
    );
  };

  const handleSelectAll = () => {
    if (selectedContracts.length === currentContracts.length) {
      setSelectedContracts([]);
    } else {
      setSelectedContracts(currentContracts.map(contract => contract.id));
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* 头部 */}
      <div className="bg-card border-b border-border px-6 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={onBack} className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4" />
              返回
            </Button>
            <div>
              <h1 className="text-lg font-medium text-foreground">合同信息 - {workzone?.name}</h1>
              <p className="text-sm text-muted-foreground">工区相关的所有合同协议信息</p>
            </div>
          </div>
          <div className="flex gap-3">
            {selectedContracts.length > 0 && (
              <Button variant="outline" className="flex items-center gap-2">
                <Download className="w-4 h-4" />
                批量下载 ({selectedContracts.length})
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="p-6">
        <Card className="p-6 border border-border">
          {/* 合同统计 */}
          <div className="mb-6">
            <div className="grid grid-cols-5 gap-4">
              <Card className="p-4 bg-primary/5 border border-primary/20">
                <div className="text-center">
                  <div className="text-2xl font-medium text-primary">{mockContracts.length}</div>
                  <div className="text-sm text-muted-foreground">总合同数</div>
                </div>
              </Card>
              <Card className="p-4 bg-green-50 border border-green-200">
                <div className="text-center">
                  <div className="text-2xl font-medium text-green-700">
                    {mockContracts.filter(c => c.status === '生效中').length}
                  </div>
                  <div className="text-sm text-muted-foreground">生效中</div>
                </div>
              </Card>
              <Card className="p-4 bg-gray-50 border border-gray-200">
                <div className="text-center">
                  <div className="text-2xl font-medium text-gray-700">
                    {mockContracts.filter(c => c.status === '已完成').length}
                  </div>
                  <div className="text-sm text-muted-foreground">已完成</div>
                </div>
              </Card>
              <Card className="p-4 bg-yellow-50 border border-yellow-200">
                <div className="text-center">
                  <div className="text-2xl font-medium text-yellow-700">
                    {mockContracts.filter(c => c.status === '待签署').length}
                  </div>
                  <div className="text-sm text-muted-foreground">待签署</div>
                </div>
              </Card>
              <Card className="p-4 bg-blue-50 border border-blue-200">
                <div className="text-center">
                  <div className="text-2xl font-medium text-blue-700">
                    {(mockContracts.reduce((sum, c) => sum + parseFloat(c.amount.replace(/[万元,]/g, '')), 0)).toFixed(0)}万元
                  </div>
                  <div className="text-sm text-muted-foreground">总金额</div>
                </div>
              </Card>
            </div>
          </div>

          {/* 合同列表 */}
          <div className="border border-border rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="w-12">
                    <input
                      type="checkbox"
                      checked={selectedContracts.length === currentContracts.length && currentContracts.length > 0}
                      onChange={handleSelectAll}
                      className="rounded"
                    />
                  </TableHead>
                  <TableHead className="text-foreground">合同名称</TableHead>
                  <TableHead className="text-foreground">类型</TableHead>
                  <TableHead className="text-foreground">状态</TableHead>
                  <TableHead className="text-foreground">合同方</TableHead>
                  <TableHead className="text-foreground">合同期限</TableHead>
                  <TableHead className="text-foreground">合同金额</TableHead>
                  <TableHead className="text-foreground">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {currentContracts.map((contract) => (
                  <TableRow key={contract.id} className="hover:bg-muted/50">
                    <TableCell>
                      <input
                        type="checkbox"
                        checked={selectedContracts.includes(contract.id)}
                        onChange={() => handleSelectContract(contract.id)}
                        className="rounded"
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <FileText className="w-4 h-4 text-muted-foreground" />
                        <div>
                          <div className="font-medium text-foreground">{contract.name}</div>
                          <div className="text-xs text-muted-foreground">编号: {contract.contractNumber}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-muted-foreground border-border">{contract.type}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusColor(contract.status)}>
                        {contract.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground max-w-[200px] truncate" title={contract.party}>
                      {contract.party}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Calendar className="w-3 h-3" />
                        <span className="text-xs">{contract.startDate} ~ {contract.endDate}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <DollarSign className="w-3 h-3" />
                        <span className="text-sm font-medium">{contract.amount}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="h-8 w-8 p-0 hover:bg-primary/10"
                          title="查看详情"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="h-8 w-8 p-0 hover:bg-primary/10"
                          title="下载合同"
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* 分页 */}
          <div className="flex items-center justify-between mt-4">
            <div className="text-sm text-muted-foreground whitespace-nowrap">
              显示 {startIndex + 1}-{Math.min(startIndex + pageSize, mockContracts.length)} 共 {mockContracts.length} 条
            </div>
            
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      if (currentPage > 1) setCurrentPage(currentPage - 1);
                    }}
                    className={currentPage <= 1 ? 'pointer-events-none opacity-50' : ''}
                  />
                </PaginationItem>
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const page = i + 1;
                  return (
                    <PaginationItem key={page}>
                      <PaginationLink
                        href="#"
                        isActive={page === currentPage}
                        onClick={(e) => {
                          e.preventDefault();
                          setCurrentPage(page);
                        }}
                      >
                        {page}
                      </PaginationLink>
                    </PaginationItem>
                  );
                })}
                <PaginationItem>
                  <PaginationNext 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                    }}
                    className={currentPage >= totalPages ? 'pointer-events-none opacity-50' : ''}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </div>
        </Card>
      </div>
    </div>
  );
}