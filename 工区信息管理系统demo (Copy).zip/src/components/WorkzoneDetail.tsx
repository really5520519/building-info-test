import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { ArrowLeft, MapPin, FileText, Folder, Edit, X, Save, Send } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface WorkzoneDetailProps {
  workzone: any;
  onBack: () => void;
  onFloorPlanClick: () => void;
  onFilesClick: () => void;
  onMapLocationClick: () => void;
  onContractClick: () => void;
  defaultTab?: string;
}

export default function WorkzoneDetail({ 
  workzone, 
  onBack, 
  onFloorPlanClick, 
  onFilesClick, 
  onMapLocationClick,
  onContractClick,
  defaultTab = 'business'
}: WorkzoneDetailProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [isConfidential, setIsConfidential] = useState(workzone?.isConfidential || false);

  if (!workzone) return null;

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
  };

  const handleSave = () => {
    console.log('保存数据');
    setIsEditing(false);
  };

  const handleSubmit = () => {
    console.log('提交数据');
    setIsEditing(false);
  };

  const InfoField = ({ label, value, editable = false }: { label: string; value: string; editable?: boolean }) => (
    <div className="space-y-1">
      <div className="text-sm text-muted-foreground">{label}</div>
      <div className="text-sm text-foreground font-medium">{value || '联办职场'}</div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* 头部导航 */}
      <div className="bg-card border-b border-border px-6 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={onBack} className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4" />
              返回
            </Button>
            <div className="flex items-center gap-3">
              <button
                className="text-primary hover:text-primary/80 hover:underline font-medium text-lg"
                onClick={onMapLocationClick}
              >
                {workzone.name}（{workzone.code}）
              </button>
              <button
                className="text-primary hover:text-primary/80 transition-colors"
                onClick={onMapLocationClick}
                title="查看在地图中的位置"
              >
                <MapPin className="w-4 h-4" />
              </button>
              <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">已交付</Badge>
              {workzone.isConfidential && (
                <Badge variant="destructive" className="bg-red-100 text-red-800 border-red-200">保密</Badge>
              )}
              <span className="text-sm text-muted-foreground">2023-01-01 - 2028-01-01</span>
            </div>
          </div>
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={onFloorPlanClick}
              className="flex items-center gap-2"
            >
              <FileText className="w-4 h-4" />
              查看图纸信息
            </Button>
            <Button 
              variant="outline" 
              onClick={onFilesClick}
              className="flex items-center gap-2"
            >
              <Folder className="w-4 h-4" />
              查看相关文件
            </Button>
            {!isEditing ? (
              <Button 
                onClick={handleEdit}
                className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <Edit className="w-4 h-4" />
                编辑
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button variant="outline" onClick={handleCancel} className="flex items-center gap-2">
                  <X className="w-4 h-4" />
                  取消
                </Button>
                <Button variant="outline" onClick={handleSave} className="flex items-center gap-2">
                  <Save className="w-4 h-4" />
                  保存
                </Button>
                <Button onClick={handleSubmit} className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground">
                  <Send className="w-4 h-4" />
                  提交
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* 灰底基础信息区1 */}
        <Card className="p-6 bg-card border border-border">
          <div className="flex items-center gap-4 mb-4">
            <h3 className="text-lg font-medium text-foreground">基础信息</h3>
            <div className="flex items-center gap-2">
              <span className={`text-sm ${isConfidential ? 'text-red-600' : 'text-muted-foreground'}`}>
                {isConfidential ? '保密' : '公开'}
              </span>
              <Switch
                checked={isConfidential}
                onCheckedChange={setIsConfidential}
                className={isConfidential ? 'data-[state=checked]:bg-red-500' : ''}
              />
            </div>
          </div>
          <div className="grid grid-cols-6 gap-6">
            <InfoField label="房产分区" value={workzone.region} />
            <InfoField label="国家/地区" value={workzone.country} />
            <InfoField label="省/州" value={workzone.province} />
            <InfoField label="城市" value={workzone.city} />
            <InfoField label="区县" value={workzone.district} />
            <InfoField label="职场名称" value={workzone.name} />
            <InfoField label="职场编号" value={workzone.code} />
            <InfoField label="职场主数据编码" value={workzone.mainDataCode} />
            <InfoField label="职场状态" value={workzone.status} />
            <InfoField label="业务类型（职场类型）" value={workzone.businessType} />
            <InfoField label="职场类型（职场功能）" value={workzone.workzoneType} />
            <InfoField label="合同地址" value={workzone.address} />
            <InfoField label="邮政编码" value={workzone.postalCode} />
            <InfoField label="办公室所属商圈/区位" value={workzone.businessDistrict} />
            <InfoField label="办公楼等级标准" value={workzone.buildingLevel} />
            <InfoField label="租赁类型" value={workzone.leaseType} />
            <InfoField label="职场租赁形式" value={workzone.leaseForm} />
            <InfoField label="是否整租" value={workzone.isFullLease ? '是' : '否'} />
            <InfoField label="是否24h职场" value={workzone.is24Hours ? '是' : '否'} />
            <InfoField label="是否高层建筑" value={workzone.isHighRise ? '是' : '否'} />
            <InfoField label="职场特殊功能/用途" value={workzone.specialFunction} />
            <InfoField label="是否共享工位职场" value={workzone.isSharedWorkspace ? '是' : '否'} />
            <InfoField label="是否园区" value={workzone.isPark ? '是' : '否'} />
            <InfoField label="是否PA推荐" value={workzone.isPARecommended ? '是' : '否'} />
            <InfoField label="楼栋数" value={workzone.buildingCount?.toString()} />
            <InfoField label="物理楼层数量" value={workzone.physicalFloors?.toString()} />
            <InfoField label="电梯楼层数量" value={workzone.elevatorFloors?.toString()} />
          </div>
        </Card>

        {/* 灰底基础信息区2 */}
        <Card className="p-6 bg-card border border-border">
          <h3 className="text-lg font-medium text-foreground mb-4">时间信息</h3>
          <div className="grid grid-cols-6 gap-6">
            <InfoField label="最早起租日期" value="2023-01-01" />
            <InfoField label="最晚到期日期" value="2028-01-01" />
            <InfoField label="最早搬入日期" value="2023-03-15" />
            <InfoField label="最晚搬出日期" value="2028-01-31" />
            <InfoField label="实际退租日期" value="-" />
            <InfoField label="*装修还原交付日期" value="-" />
          </div>
        </Card>

        {/* 详细信息Tab区域 */}
        <Tabs defaultValue={defaultTab} className="w-full">
          <TabsList className="grid w-full grid-cols-10 bg-muted">
            <TabsTrigger value="business" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">业务信息</TabsTrigger>
            <TabsTrigger value="workstation" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">工位信息</TabsTrigger>
            <TabsTrigger value="space" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">独立空间</TabsTrigger>
            <TabsTrigger value="lease" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">租赁信息</TabsTrigger>
            <TabsTrigger value="decoration" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">装修信息</TabsTrigger>
            <TabsTrigger value="design" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">设计信息</TabsTrigger>
            <TabsTrigger value="operation2" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">运营信息</TabsTrigger>
            <TabsTrigger value="compliance" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">合规信息</TabsTrigger>
            <TabsTrigger value="cost" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">成本信息</TabsTrigger>
            <TabsTrigger value="billing" className="data-[state=active]:border-b-2 data-[state=active]:border-primary">定价信息</TabsTrigger>
          </TabsList>

          <TabsContent value="business" className="mt-6">
            <Card className="p-6 border border-border">
              <h3 className="text-lg font-medium text-foreground mb-4">业务信息</h3>
              <div className="p-4 bg-muted/30 rounded-lg border border-border mb-6">
                <div className="grid grid-cols-5 gap-3 text-sm">
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">职场业务类型</span>
                    <span className="font-medium text-foreground">研发中心</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">业务分类</span>
                    <span className="font-medium text-foreground">技术研发</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">最大业务部门</span>
                    <span className="font-medium text-foreground">软件开发部</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">所有业务部门</span>
                    <span className="font-medium text-foreground">软件开发部、产品设计部、测试部</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">特殊业务说明</span>
                    <span className="font-medium text-foreground">涉及核心技术研发</span>
                  </div>
                </div>
              </div>

              <div className="border border-border rounded-lg overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="whitespace-nowrap text-foreground">楼宇</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层用途</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">1级部门数</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">1级部门名称</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">总工位数</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">分配部门名称</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">总工位���</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">分配工位数</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">未分配工位数</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">说明</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">15F</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">办公区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">3</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">软件开发部、产品设计部、测试部</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.6)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">软件开发部({Math.round(workzone.workstations * 0.35)}个)、产品设计部({Math.round(workzone.workstations * 0.15)}个)</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.6)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.5)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.1)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">主要研发区域</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                          查看详情
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">16F</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">办公区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">测试部、运维部</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">测试部({Math.round(workzone.workstations * 0.25)}个)、运维部({Math.round(workzone.workstations * 0.1)}个)</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.35)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.05)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">测试和运维区域</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                          查看详情
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">1F</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">餐厅</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">员工餐厅，{Math.round(workzone.workstations * 0.5)}个餐位</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                          查看详情
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">B1F</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">停车场</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">地下停车场，{Math.round(workzone.workstations * 0.4)}个停车位</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                          查看详情
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2F</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">服务区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">1</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">行政服务部</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.1)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">行政服务部({Math.round(workzone.workstations * 0.08)}个)</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.1)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.08)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.02)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">行政服务区，含会议室和接待区</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                          查看详情
                        </Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="workstation" className="mt-6 space-y-6">
            {/* 表格区 */}
            <Card className="p-6 border border-border">
              <h3 className="text-lg font-medium text-foreground mb-4">工位信息</h3>
              
              {/* 统计信息行 */}
              <div className="mb-6 p-4 bg-muted/30 rounded-lg border border-border">
                <div className="grid grid-cols-11 gap-3 text-sm">
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">总工位数</span>
                    <span className="font-medium text-foreground">{workzone.workstations}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">已交付工位数</span>
                    <span className="font-medium text-foreground">{workzone.status === '已交付' ? workzone.workstations : workzone.status === '已退租' ? 0 : 0}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">未交付工位数</span>
                    <span className="font-medium text-foreground">{workzone.status === '未交付' ? workzone.workstations : 0}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">已退租工位数</span>
                    <span className="font-medium text-foreground">{workzone.status === '已退租' ? workzone.workstations : 0}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">总建筑面积</span>
                    <span className="font-medium text-foreground">{Math.round(workzone.area * 1.2)}㎡</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">总租赁面积</span>
                    <span className="font-medium text-foreground">{workzone.area}㎡</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">总使用面积</span>
                    <span className="font-medium text-foreground">{Math.round(workzone.area * 0.85)}㎡</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">已交付租赁面积</span>
                    <span className="font-medium text-foreground">{workzone.status === '已交付' ? workzone.area : workzone.status === '已退租' ? 0 : 0}㎡</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">未交付租赁面积</span>
                    <span className="font-medium text-foreground">{workzone.status === '未交付' ? workzone.area : 0}㎡</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">已退租租赁面积</span>
                    <span className="font-medium text-foreground">{workzone.status === '已退租' ? workzone.area : 0}㎡</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">使用周期（最早-最晚）</span>
                    <span className="font-medium text-foreground">2023.01.01-2028.01.01</span>
                  </div>
                </div>
              </div>

              <div className="border border-border rounded-lg overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="whitespace-nowrap text-foreground">楼栋</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层用途</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层状态</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">未交付工位数</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">已退租工位数</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">建筑面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">租赁面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">使用面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">得房率</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">使用率</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">已交付租赁面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">未交付租赁面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">已退租租赁面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">起租日期</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">退租日期</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">实际交付日期</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">搬家入住日期</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">实际退租日期</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {/* 模拟楼栋楼层数据 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">15F</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">标准办公</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '未交付' ? Math.round(workzone.workstations * 0.6) : 0}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '已退租' ? Math.round(workzone.workstations * 0.6) : 0}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.6 * 1.2)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.6)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.6 * 0.85)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">85%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round((workzone.businessUsage * 0.6 / (workzone.workstations * 0.6)) * 100)}%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '已交付' ? Math.round(workzone.area * 0.6) : workzone.status === '已退租' ? 0 : 0}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '未交付' ? Math.round(workzone.area * 0.6) : 0}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '已退租' ? Math.round(workzone.area * 0.6) : 0}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023-01-01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2028-01-01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '已交付' ? '2023-03-15' : '-'}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '已交付' ? '2023-04-01' : '-'}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.status === '已退租' ? '2024-06-30' : '-'}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-primary hover:text-primary"
                          >
                            详情
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-primary hover:text-primary"
                          >
                            编辑
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">16F</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">标准办公</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="bg-gray-100 text-gray-800">
                          未交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.4 * 1.2)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.4)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.4 * 0.85)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">85%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.4)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2024-01-01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2029-01-01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-primary hover:text-primary"
                          >
                            详情
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-primary hover:text-primary"
                          >
                            编辑
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">14F</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">标准办公</TableCell>
                      <TableCell>
                        <Badge variant="destructive" className="bg-red-100 text-red-800">
                          已退租
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.3)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.3 * 1.2)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.3)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.3 * 0.85)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">85%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.3)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2022-01-01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2024-01-01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2022-03-15</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2022-04-01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2024-01-31</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-primary hover:text-primary"
                          >
                            详情
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-primary hover:text-primary"
                          >
                            编辑
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="space" className="mt-6">
            <Card className="p-6 border border-border">
              <h3 className="text-lg font-medium text-foreground mb-4">独立空间</h3>
              
              {/* 统计信息区域 */}
              <div className="mb-6 p-4 bg-muted/30 rounded-lg border border-border">
                <div className="grid grid-cols-11 gap-3 text-sm">
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">办公空间数量</span>
                    <span className="font-medium text-foreground">{Math.round(workzone.workstations * 0.8)}个</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">会议协作空间数量</span>
                    <span className="font-medium text-foreground">{Math.round(workzone.workstations * 0.15)}个</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">业务特殊空间数量</span>
                    <span className="font-medium text-foreground">{Math.round(workzone.workstations * 0.05)}个</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">支持功能空间数量</span>
                    <span className="font-medium text-foreground">{Math.round(workzone.facilities * 0.4)}个</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">康体空间数量</span>
                    <span className="font-medium text-foreground">{Math.round(workzone.facilities * 0.1)}个</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">餐饮空间数量</span>
                    <span className="font-medium text-foreground">{Math.round(workzone.facilities * 0.2)}个</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">访客空间数量</span>
                    <span className="font-medium text-foreground">{Math.round(workzone.facilities * 0.1)}个</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">运营空间数量</span>
                    <span className="font-medium text-foreground">{Math.round(workzone.facilities * 0.2)}个</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">未定义空间数量</span>
                    <span className="font-medium text-foreground">2个</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">总空间面积</span>
                    <span className="font-medium text-foreground">{workzone.area}㎡</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">空间利用率</span>
                    <span className="font-medium text-foreground">85%</span>
                  </div>
                </div>
              </div>

              {/* 独立空间详细表格 */}
              <div className="border border-border rounded-lg overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="whitespace-nowrap text-foreground">楼宇</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层状态</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层用途</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">空间类型数量</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">空间总面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">上线数量</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">下线数量</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">已分配数量</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">未分配数量</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {/* 15F 办公区 - 已交付 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">15F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          ��交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">办公区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.8)}个</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.6)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.6)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.55)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.05)}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                          查看详情
                        </Button>
                      </TableCell>
                    </TableRow>
                    
                    {/* 16F ���公区 - 未交付 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">16F</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="bg-gray-100 text-gray-800">
                          未交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">办公区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}个</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.25)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                          查看详情
                        </Button>
                      </TableCell>
                    </TableRow>
                    
                    {/* 1F 餐厅 - 已交付 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">1F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">餐厅</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.facilities * 0.2)}个</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.05)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.facilities * 0.2)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.facilities * 0.2)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                          查看详情
                        </Button>
                      </TableCell>
                    </TableRow>
                    
                    {/* B1F 停车场 - 已退租 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">B1F</TableCell>
                      <TableCell>
                        <Badge variant="destructive" className="bg-red-100 text-red-800">
                          已退租
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">停车场</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}个</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.08)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                          查看详情
                        </Button>
                      </TableCell>
                    </TableRow>
                    
                    {/* 2F 服���区 - 已交付 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">服务区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.facilities * 0.4)}个</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.02)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.facilities * 0.35)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.facilities * 0.32)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.facilities * 0.03)}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary">
                          查看详情
                        </Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="lease" className="mt-6">
            <Card className="p-6 border border-border">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-foreground">租赁信息</h3>
                <button
                  onClick={onContractClick}
                  className="text-primary hover:text-primary/80 hover:underline text-sm transition-colors"
                >
                  查看所有合同信息
                </button>
              </div>
              <div className="space-y-4">

                <div className="p-4 bg-muted/30 rounded-lg border border-border">
                  <div className="grid grid-cols-11 gap-3 text-sm">
                    <div className="flex flex-col">
                      <span className="text-muted-foreground">有效租赁合同总金额</span>
                      <span className="font-medium text-foreground">{Math.round(workzone.area * 300)}万元</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-muted-foreground">有效物业费总金额</span>
                      <span className="font-medium text-foreground">{Math.round(workzone.area * 60)}万元</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-muted-foreground">物业费标准</span>
                      <span className="font-medium text-foreground">50元/㎡/月</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-muted-foreground">平均月租金</span>
                      <span className="font-medium text-foreground">{Math.round(workzone.area * 5)}万元</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-muted-foreground">租赁总成本（含税）</span>
                      <span className="font-medium text-foreground">{Math.round(workzone.area * 360)}万元</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-muted-foreground">租赁成本（含税）</span>
                      <span className="font-medium text-foreground">{Math.round(workzone.area * 300)}万元</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-muted-foreground">租金成本（含税）</span>
                      <span className="font-medium text-foreground">{Math.round(workzone.area * 300)}万元</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-muted-foreground">物业成本（含税）</span>
                      <span className="font-medium text-foreground">{Math.round(workzone.area * 60)}万元</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-muted-foreground">其他费用（含税）</span>
                      <span className="font-medium text-foreground">{Math.round(workzone.area * 10)}万元</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-muted-foreground">押金/保证金总金额</span>
                      <span className="font-medium text-foreground">{Math.round(workzone.area * 20)}万元</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-muted-foreground">表面租金/有效租金</span>
                      <span className="font-medium text-foreground">8.2/7.8元/㎡/天</span>
                    </div>
                  </div>
                </div>
                
                {/* 租赁合同详情表格 */}
                <div className="mt-6">
                  <h4 className="mb-4 font-medium text-foreground">租赁合同详情</h4>
                  <div className="border border-border rounded-lg overflow-hidden">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-muted/50">
                            <TableHead className="whitespace-nowrap text-foreground">楼宇</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">楼层</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">楼层状态</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">楼层用途</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">合同ID</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">合同名称</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">当前状态</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">业主</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">物业公司</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">合同金额</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">租赁方式</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">租赁面积</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">起租日期</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">到期日期</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">免租月数/天数</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">租金金额</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">物业费金��</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">其他金额</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">押金/保证金金额</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">房租税率</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">物业费税率</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">平均月租金</TableHead>
                            <TableHead className="whitespace-nowrap text-foreground">物业费标准</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          <TableRow>
                            <TableCell className="text-foreground">金融街中心</TableCell>
                            <TableCell className="text-foreground">18层</TableCell>
                            <TableCell>
                              <Badge variant="default" className="bg-primary text-primary-foreground">
                                ��交付
                              </Badge>
                            </TableCell>
                            <TableCell className="text-foreground">办公</TableCell>
                            <TableCell className="text-foreground">HT20230101</TableCell>
                            <TableCell className="text-foreground">金融街中心18层租赁合同</TableCell>
                            <TableCell>
                              <Badge variant="default" className="bg-green-500 text-white">
                                执行中
                              </Badge>
                            </TableCell>
                            <TableCell className="text-foreground">某某地产发展有限公司</TableCell>
                            <TableCell className="text-foreground">某某物业管理有限公司</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 300)}万元</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                                新租
                              </Badge>
                            </TableCell>
                            <TableCell className="text-foreground">{workzone.area}���</TableCell>
                            <TableCell className="text-foreground">2023-01-01</TableCell>
                            <TableCell className="text-foreground">2028-01-01</TableCell>
                            <TableCell className="text-foreground">2个月</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 280)}万元</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 60)}万元</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 10)}万元</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 20)}万元</TableCell>
                            <TableCell className="text-foreground">6%</TableCell>
                            <TableCell className="text-foreground">6%</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 5)}万元</TableCell>
                            <TableCell className="text-foreground">50元/㎡/月</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="text-foreground">金融街中心</TableCell>
                            <TableCell className="text-foreground">19层</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="bg-gray-100 text-gray-800">
                                未交付
                              </Badge>
                            </TableCell>
                            <TableCell className="text-foreground">办公</TableCell>
                            <TableCell className="text-foreground">HT20240601</TableCell>
                            <TableCell className="text-foreground">金融街中心19层扩租合同</TableCell>
                            <TableCell>
                              <Badge variant="default" className="bg-green-500 text-white">
                                执行中
                              </Badge>
                            </TableCell>
                            <TableCell className="text-foreground">某某地产发展有限公司</TableCell>
                            <TableCell className="text-foreground">某某物业管理有限公司</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 120)}万元</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                                扩租
                              </Badge>
                            </TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 0.4)}㎡</TableCell>
                            <TableCell className="text-foreground">2024-06-01</TableCell>
                            <TableCell className="text-foreground">2028-01-01</TableCell>
                            <TableCell className="text-foreground">1个月</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 110)}万元</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 24)}万元</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 4)}万元</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 8)}万元</TableCell>
                            <TableCell className="text-foreground">6%</TableCell>
                            <TableCell className="text-foreground">6%</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 2)}万元</TableCell>
                            <TableCell className="text-foreground">50元/㎡/月</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="text-foreground">金融街中心</TableCell>
                            <TableCell className="text-foreground">17层</TableCell>
                            <TableCell>
                              <Badge variant="destructive" className="bg-red-100 text-red-800">
                                已退租
                              </Badge>
                            </TableCell>
                            <TableCell className="text-foreground">办公</TableCell>
                            <TableCell className="text-foreground">HT20220101</TableCell>
                            <TableCell className="text-foreground">金融街中心17层租赁合同</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="bg-gray-100 text-gray-800">
                                已完结
                              </Badge>
                            </TableCell>
                            <TableCell className="text-foreground">某某地产发展有限公司</TableCell>
                            <TableCell className="text-foreground">某某物业管理有限公司</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 150)}万元</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                                退租
                              </Badge>
                            </TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 0.3)}㎡</TableCell>
                            <TableCell className="text-foreground">2022-01-01</TableCell>
                            <TableCell className="text-foreground">2024-01-01</TableCell>
                            <TableCell className="text-foreground">1个月</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 140)}万元</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 18)}万元</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 3)}万元</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 6)}万元</TableCell>
                            <TableCell className="text-foreground">6%</TableCell>
                            <TableCell className="text-foreground">6%</TableCell>
                            <TableCell className="text-foreground">{Math.round(workzone.area * 1.5)}万元</TableCell>
                            <TableCell className="text-foreground">45元/㎡/月</TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="decoration" className="mt-6">
            <Card className="p-6 border border-border">
              <h3 className="text-lg font-medium text-foreground mb-4">装修信息</h3>
              
              <div className="border border-border rounded-lg overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="whitespace-nowrap text-foreground">楼宇</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层状态</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层用途</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">装修项目ID</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">装修项目名称</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">装修交付时间</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">竣备日期</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">交付工位数</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">装修面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">项目立项金额</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">项目结算金额</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {/* 15F 办公区装修项目 - 已交付 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">15F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">标准办公区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">ZX-2023-001</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">A栋15层办公区域精装修工程</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023-03-15</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023-03-20</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.6)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.6)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">￥{Math.round(workzone.area * 0.6 * 2800).toLocaleString()}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">￥{Math.round(workzone.area * 0.6 * 2650).toLocaleString()}</TableCell>
                    </TableRow>
                    
                    {/* 16F 办公区装修项目 - ���交付 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">16F</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="bg-gray-100 text-gray-800">
                          未交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">标准办公区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">ZX-2023-002</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">A栋16层办公区域精装修工程</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2024-02-28</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2024-03-05</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.25)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">￥{Math.round(workzone.area * 0.25 * 3000).toLocaleString()}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                    </TableRow>
                    
                    {/* 1F 餐厅装修项目 - 已交付 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">1F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">员工餐厅</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">ZX-2023-003</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">A栋1层员工餐厅装修工程</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023-02-20</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023-02-25</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.05)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">￥{Math.round(workzone.area * 0.05 * 4200).toLocaleString()}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">￥{Math.round(workzone.area * 0.05 * 4050).toLocaleString()}</TableCell>
                    </TableRow>
                    
                    {/* B1F 停车场装修项目 - 已退租 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">B1F</TableCell>
                      <TableCell>
                        <Badge variant="destructive" className="bg-red-100 text-red-800">
                          已退租
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">地下停车场</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">ZX-2022-015</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">A栋地下停车场改造工程</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2022-12-15</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2022-12-20</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.08)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">￥{Math.round(workzone.area * 0.08 * 1800).toLocaleString()}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">￥{Math.round(workzone.area * 0.08 * 1750).toLocaleString()}</TableCell>
                    </TableRow>
                    
                    {/* 2F 服务区装修项目 - 已交付 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">行政服务区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">ZX-2023-004</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">A栋2层行政服务区装修工程</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023-01-25</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023-01-30</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.1)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.02)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">￥{Math.round(workzone.area * 0.02 * 3500).toLocaleString()}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">￥{Math.round(workzone.area * 0.02 * 3350).toLocaleString()}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="design" className="mt-6">
            <Card className="p-6 border border-border">
              <h3 className="text-lg font-medium text-foreground mb-4">设计信息</h3>
              
              <div className="border border-border rounded-lg overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="whitespace-nowrap text-foreground">楼宇</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层状态</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层用途</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层密度档位</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">层高（楼板高度）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">层高（吊顶高度）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层布局</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">自然采光</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">称重信息</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">玻璃幕墙占比</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">工位区使用面积（职场）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">会议室使用面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">协作区使用面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">其他区域面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">单工位租赁面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">单工位使用面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">普通挡板工位数量</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">升降桌1.2数量</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">UPS工位数量</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">带网口工位数量</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {/* 15F 办公区设计信息 - 已交付 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">15F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">标准办公区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">A+</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">3.6m</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2.8m</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">办公区+会议+公共协作</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">A类-75%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">300kg/㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">85%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.45)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.1)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.05)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.1)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">8.5㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">6.8㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.15)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.05)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.6)}</TableCell>
                    </TableRow>
                    
                    {/* 16F 办公区设计信息 - 未交付 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">16F</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="bg-gray-100 text-gray-800">
                          未交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">标准办公区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">A</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">3.6m</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2.8m</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">办公区+会议+休息区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">A类-70%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">300kg/㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">80%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.18)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.04)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.03)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.05)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">7.5㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">6.0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.3)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.08)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.02)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}</TableCell>
                    </TableRow>
                    
                    {/* 1F 餐厅设计信息 - 已交付 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">1F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">员工餐厅</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">B</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">4.2m</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">3.5m</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">餐饮区+厨房+储物</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">B类-50%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">500kg/㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">60%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.05)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                    </TableRow>
                    
                    {/* B1F 停车场设计信息 - 已退租 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">B1F</TableCell>
                      <TableCell>
                        <Badge variant="destructive" className="bg-red-100 text-red-800">
                          已退租
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">地下停车场</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">B-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">3.2m</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">3.2m</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">停车位+通道+设备</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">C类-20%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">800kg/㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.08)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                    </TableRow>
                    
                    {/* 2F 服务区设计信息 - 已交付 */}
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">行政服务区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">A</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">3.8m</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">3.0m</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">接待+会议+办公</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">A类-65%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">300kg/㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">75%</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.015)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.003)}��</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.002)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.005)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">10.0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">8.0㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.06)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.02)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.01)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.1)}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="operation2" className="mt-6">
            <Card className="p-6 border border-border">
              <h3 className="text-lg font-medium text-foreground mb-4">运营信息</h3>
              
              {/* 基础运营信息 */}
              <div className="mb-6 p-4 bg-muted/30 rounded-lg border border-border">
                <div className="grid grid-cols-6 gap-3 text-sm">
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">供电电源类型</span>
                    <span className="font-medium text-foreground">市政供电+自备发电机</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">是否行政驻场</span>
                    <span className="font-medium text-foreground">是</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">是否供餐职场</span>
                    <span className="font-medium text-foreground">是</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">是否开火职场</span>
                    <span className="font-medium text-foreground">否</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">健身房数量</span>
                    <span className="font-medium text-foreground">1个</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">餐厅数量</span>
                    <span className="font-medium text-foreground">1个</span>
                  </div>
                </div>
              </div>

              {/* 门禁安保信息 */}
              <div className="mb-6 p-4 bg-muted/30 rounded-lg border border-border">
                <div className="grid grid-cols-6 gap-3 text-sm">
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">门禁类型</span>
                    <span className="font-medium text-foreground">指纹识别+刷卡</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">门禁状况</span>
                    <span className="font-medium text-foreground">正常运行</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">是否物业闸机</span>
                    <span className="font-medium text-foreground">是</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">是否安保人员驻场</span>
                    <span className="font-medium text-foreground">是</span>
                  </div>
                </div>
              </div>

              {/* 空调信息 */}
              <div className="mb-6 p-4 bg-muted/30 rounded-lg border border-border">
                <div className="grid grid-cols-6 gap-3 text-sm">
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">空调系统类型</span>
                    <span className="font-medium text-foreground">中央空调</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">空调制冷日期</span>
                    <span className="font-medium text-foreground">5月1日-10月31日</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">空调供暖日期</span>
                    <span className="font-medium text-foreground">11月1日-4月30日</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">周末是否有空调</span>
                    <span className="font-medium text-foreground">是</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">可加时的时段</span>
                    <span className="font-medium text-foreground">18:00-22:00</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">空调加时收费标准</span>
                    <span className="font-medium text-foreground">50元/小时</span>
                  </div>
                </div>
              </div>

              {/* 电梯信息 */}
              <div className="p-4 bg-muted/30 rounded-lg border border-border">
                <div className="grid grid-cols-6 gap-3 text-sm">
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">电梯信息</span>
                    <span className="font-medium text-foreground">高速客梯+货梯配置</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">电梯数量（台）-客梯</span>
                    <span className="font-medium text-foreground">4台</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">电梯数量（台）-货梯</span>
                    <span className="font-medium text-foreground">2台</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">电梯数量（台）-扶梯或其他</span>
                    <span className="font-medium text-foreground">1台（自动扶梯）</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">电梯品牌</span>
                    <span className="font-medium text-foreground">奥的斯</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">电梯型号（自建/自持需附参数清单）</span>
                    <span className="font-medium text-foreground">GeN2-MRL（载重1350kg，速度2.5m/s）</span>
                  </div>
                </div>
                <div className="grid grid-cols-6 gap-3 text-sm mt-3">
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">有无电梯机房</span>
                    <span className="font-medium text-foreground">无机房设计</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">使用年限（年）</span>
                    <span className="font-medium text-foreground">3年</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">电梯管理方</span>
                    <span className="font-medium text-foreground">某某电梯维保有限公司</span>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>



          <TabsContent value="compliance" className="mt-6">
            <Card className="p-6 border border-border">
              <h3 className="text-lg font-medium text-foreground mb-4">合规信息</h3>
              <div className="border border-border rounded-lg overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="whitespace-nowrap text-foreground">楼宇</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层状态</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">楼层用途</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">消防合规工位数（楼层）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">合规结果</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">产权方</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">出租方</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">产权方与出租方关系</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">出租链条</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">15F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">标准办公</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.6)}</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-blue-100 text-blue-800 border-blue-200">
                          合规
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">某某地产发展有限公司</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">某某地产发展有限公司</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">自有物业</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">产权方直租</TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">16F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">标准办公</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.4)}</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                          合规已降险
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">某某地产发展有限公司</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">某某地产发展有限公司</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">自有物业</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">产权方直租</TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">1F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">餐厅</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-blue-100 text-blue-800 border-blue-200">
                          合规
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">某某地产发展有限公司</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">某某地产发展有限公司</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">自有物业</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">产权方直租</TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">B1F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">停车场</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">0</TableCell>
                      <TableCell>
                        <Badge variant="destructive" className="bg-red-100 text-red-800 border-red-200">
                          瑕疵
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">某某地产发展有限公司</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">某某物业管理有限公司</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">委托经营</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">产权方-物业公司-承租方</TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">A栋</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2F</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-primary text-primary-foreground">
                          已交付
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">服务区</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.workstations * 0.1)}</TableCell>
                      <TableCell>
                        <Badge variant="default" className="bg-blue-100 text-blue-800 border-blue-200">
                          合规
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">某某地产发展有限公司</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">某某地产发展有限公��</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">自有物业</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">产权方直租</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="cost" className="mt-6">
            <Card className="p-6 border border-border">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-foreground">成本信息</h3>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">年度：</span>
                    <Select defaultValue="2023">
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="2023">2023</SelectItem>
                        <SelectItem value="2024">2024</SelectItem>
                        <SelectItem value="2025">2025</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">月份：</span>
                    <Select defaultValue="05">
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全年</SelectItem>
                        <SelectItem value="01">01月</SelectItem>
                        <SelectItem value="02">02月</SelectItem>
                        <SelectItem value="03">03月</SelectItem>
                        <SelectItem value="04">04月</SelectItem>
                        <SelectItem value="05">05月</SelectItem>
                        <SelectItem value="06">06月</SelectItem>
                        <SelectItem value="07">07月</SelectItem>
                        <SelectItem value="08">08月</SelectItem>
                        <SelectItem value="09">09月</SelectItem>
                        <SelectItem value="10">10月</SelectItem>
                        <SelectItem value="11">11月</SelectItem>
                        <SelectItem value="12">12月</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <div className="border border-border rounded-lg overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="whitespace-nowrap text-foreground">年度</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">月份</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">全周期总成本</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">房产总成本（管理期）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">租赁总成本（含税）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">租��成本（含税）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">租金成本（含税）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">物业成本（含税）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">其他���用（含税）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">『押金/保证金』总金额（本次）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">复原费（含税）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">装修成本（含税）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">顾问服务费（含税）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">工程费用（含税）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">家具/固定装置/设备费用（含税）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">运营成本</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">房产部门成本</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">单月总成本（含税）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">单工位成本（工位费用）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">单工位费用（合同公务收费标准）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">单平米成本（元/平米）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">单面积���赁成本（元/平米/月or天）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">单面积租金（元/平米/月or天）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">单面积物业费（元/平米/月or天）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">单面积运营成本（元/平米/月）</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">2023</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">1月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥85,600,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥65,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥58,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥45,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥38,500,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥7,300,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥12,400,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥8,500,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥2,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥15,600,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥9,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥2,600,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥4,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥1,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥7,133,333</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(7133333 / workzone.workstations)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,200</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(7133333 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(58200000 / 12 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(38500000 / 12 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(7300000 / 12 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(4200000 / 12 / workzone.area)}</TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">2023</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥85,600,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥65,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥58,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥45,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥38,500,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥7,300,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥12,400,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥4,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥1,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥4,850,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(4850000 / workzone.workstations)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,200</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(4850000 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(58200000 / 12 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(38500000 / 12 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(7300000 / 12 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(4200000 / 12 / workzone.area)}</TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">2023</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">3月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥85,600,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥65,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥58,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥45,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥38,500,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥7,300,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥12,400,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥4,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥1,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥4,850,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(4850000 / workzone.workstations)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,200</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(4850000 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(58200000 / 12 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(38500000 / 12 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(7300000 / 12 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(4200000 / 12 / workzone.area)}</TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">2023</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">4月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥85,600,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥65,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥58,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥45,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥38,500,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥7,300,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥12,400,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥0</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥4,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥1,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥4,850,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(4850000 / workzone.workstations)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,200</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(4850000 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(58200000 / 12 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(38500000 / 12 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(7300000 / 12 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(4200000 / 12 / workzone.area)}</TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">2023</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">年度合计</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥85,600,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥65,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥58,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥45,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥38,500,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥7,300,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥12,400,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥8,500,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥2,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥15,600,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥9,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥2,600,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥16,800,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥7,200,000</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥65,983,333</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(65983333 / workzone.workstations)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥38,400</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(65983333 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(58200000 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(38500000 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(7300000 / workzone.area)}</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(16800000 / workzone.area)}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="billing" className="mt-6">
            <Card className="p-6 border border-border">
              <h3 className="text-lg font-medium text-foreground mb-4">定价信息</h3>
              <div className="border border-border rounded-lg overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="whitespace-nowrap text-foreground">年度</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">月份</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">工位服务单价（房产）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">独立空间服务单价（房产）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">房产管理成本</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">1.2升降桌服务单价</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">1.4升降桌服务单价</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">Plus升降桌服务单价</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">职场计费方式</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">计价面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">计价工位数</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">独立空间分配面积</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">定价适用期间</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">定价适用期间（租赁合同）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">定价适用期间（装修期）</TableHead>
                      <TableHead className="whitespace-nowrap text-foreground">定价适用期间（运营期）</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">2023</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">1月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,200/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥180/㎡/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(workzone.area * 15)}/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,500/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,800/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥4,200/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">按工位计费</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.area}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.workstations}个</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.15)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2023.12.31</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2028.01.01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2022.10.01-2023.01.01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2028.01.01</TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">2023</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,200/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥180/㎡/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(workzone.area * 15)}/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,500/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,800/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥4,200/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">按工位计费</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.area}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.workstations}个</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.15)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2023.12.31</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2028.01.01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2022.10.01-2023.01.01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2028.01.01</TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">2023</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">3月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,200/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥180/㎡/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(workzone.area * 15)}/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,500/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,800/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥4,200/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">按工位计费</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.area}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.workstations}个</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.15)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2023.12.31</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2028.01.01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2022.10.01-2023.01.01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2028.01.01</TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">2024</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">1月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,296/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥185/㎡/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(workzone.area * 15.5)}/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,605/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥3,914/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥4,326/月</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">按工位计费</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.area}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.workstations}个</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.15)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2024.01.01-2024.12.31</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2028.01.01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2028.01.01</TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/50">
                      <TableCell className="whitespace-nowrap text-foreground">2024</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">年度合计</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥39,552/年</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥2,220/㎡/年</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥{Math.round(workzone.area * 186)}/年</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥43,260/年</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥46,968/年</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">¥51,912/年</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">按工位计费</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.area}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{workzone.workstations}个</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">{Math.round(workzone.area * 0.15)}㎡</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2024.01.01-2024.12.31</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2028.01.01</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">-</TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">2023.01.01-2028.01.01</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}