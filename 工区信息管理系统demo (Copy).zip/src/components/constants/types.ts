export interface WorkzoneData {
  id: string;
  name: string;
  code: string;
  address: string;
  status: string;
  area: number;
  workstations: number;
  businessUsage: number;
  vacant: number;
  facilities: number;
  region: string;
  country: string;
  province: string;
  city: string;
  district: string;
  mainDataCode: string;
  businessType: string;
  workzoneType: string;
  postalCode: string;
  businessDistrict: string;
  buildingLevel: string;
  leaseType: string;
  leaseForm: string;
  isFullLease: boolean;
  is24Hours: boolean;
  isHighRise: boolean;
  specialFunction: string;
  isConfidential: boolean;
  isSharedWorkspace: boolean;
  isPark: boolean;
  isPARecommended: boolean;
  buildingCount: number;
  physicalFloors: number;
  elevatorFloors: number;
}

export interface StatisticsData {
  workzones: {
    total: number;
    delivered: number;
    undelivered: number;
    new: number;
    plannedExit: number;
  };
  workstations: {
    total: number;
    delivered: number;
    undelivered: number;
    new: number;
    plannedExit: number;
  };
  area: {
    total: number;
    delivered: number;
    undelivered: number;
    new: number;
    plannedExit: number;
  };
}

export interface FileData {
  id: string;
  name: string;
  type: string;
  status: string;
  uploader: string;
  updateDate: string;
  size: string;
}