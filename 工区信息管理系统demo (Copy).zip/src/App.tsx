import React, { useState } from 'react';
import { Button } from './components/ui/button';
import { ArrowLeft } from 'lucide-react';
import WorkzoneDashboard from './components/WorkzoneDashboard';
import WorkzoneMap from './components/WorkzoneMap';
import WorkzoneDetail from './components/WorkzoneDetail';
import FloorPlanInfo from './components/FloorPlanInfo';
import RelatedFiles from './components/RelatedFiles';
import AddWorkzone from './components/AddWorkzone';
import AddWorkzoneStep2 from './components/AddWorkzoneStep2';
import AddWorkzoneStep3 from './components/AddWorkzoneStep3';
import ContractInfo from './components/ContractInfo';
import { WorkzoneData } from './components/constants/types';
import { Toaster } from 'sonner@2.0.3';

type Page = 'dashboard' | 'map' | 'detail' | 'floorplan' | 'files' | 'add' | 'add-step2' | 'add-step3' | 'contract';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [selectedWorkzone, setSelectedWorkzone] = useState<WorkzoneData | null>(null);
  const [selectedWorkzoneLocation, setSelectedWorkzoneLocation] = useState<{lat: number, lng: number} | null>(null);
  const [detailDefaultTab, setDetailDefaultTab] = useState<string>('business');
  const [addWorkzoneData, setAddWorkzoneData] = useState<any>(null);

  const handleWorkzoneSelect = (workzone: WorkzoneData, defaultTab?: string) => {
    setSelectedWorkzone(workzone);
    setDetailDefaultTab(defaultTab || 'business');
    setCurrentPage('detail');
  };

  const handleMapIconClick = (workzone: WorkzoneData, location: {lat: number, lng: number}) => {
    setSelectedWorkzone(workzone);
    setSelectedWorkzoneLocation(location);
  };

  const handleMapToDetail = (workzone: WorkzoneData) => {
    setSelectedWorkzone(workzone);
    setCurrentPage('detail');
  };

  const handleAddWorkzoneStep1 = (data: any) => {
    console.log('第一步数据:', data);
    setAddWorkzoneData(data);
    setCurrentPage('add-step2');
  };

  const handleAddWorkzoneStep2 = (data: any) => {
    console.log('第二步数据:', data);
    setAddWorkzoneData(data);
    setCurrentPage('add-step3');
  };

  const handleAddWorkzoneStep3 = (data: any) => {
    console.log('完整工区数据:', data);
    // 这里可以添加保存工区数据的逻辑
    setCurrentPage('dashboard');
    setAddWorkzoneData(null);
  };

  const handleSaveDraft = (data: any) => {
    console.log('保存草稿:', data);
    // 这里可以添加保存草稿数据的逻辑
    // 草稿可以保存到本地存储或发送到服务器
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return (
          <WorkzoneDashboard 
            onWorkzoneSelect={handleWorkzoneSelect}
            onMapClick={() => setCurrentPage('map')}
            onAddClick={() => setCurrentPage('add')}
          />
        );
      case 'map':
        return (
          <WorkzoneMap 
            onBack={() => setCurrentPage('dashboard')}
            onIconClick={handleMapIconClick}
            onMoreInfo={handleMapToDetail}
            selectedLocation={selectedWorkzoneLocation}
          />
        );
      case 'detail':
        return (
          <WorkzoneDetail 
            workzone={selectedWorkzone}
            onBack={() => setCurrentPage('dashboard')}
            onFloorPlanClick={() => setCurrentPage('floorplan')}
            onFilesClick={() => setCurrentPage('files')}
            onMapLocationClick={() => setCurrentPage('map')}
            onContractClick={() => setCurrentPage('contract')}
            defaultTab={detailDefaultTab}
          />
        );
      case 'floorplan':
        return (
          <FloorPlanInfo 
            workzone={selectedWorkzone}
            onBack={() => setCurrentPage('detail')}
          />
        );
      case 'files':
        return (
          <RelatedFiles 
            workzone={selectedWorkzone}
            onBack={() => setCurrentPage('detail')}
          />
        );
      case 'add':
        return (
          <AddWorkzone 
            onBack={() => setCurrentPage('dashboard')}
            onSubmit={handleAddWorkzoneStep1}
            onSaveDraft={handleSaveDraft}
          />
        );
      case 'add-step2':
        return (
          <AddWorkzoneStep2 
            onBack={() => setCurrentPage('add')}
            onSubmit={handleAddWorkzoneStep2}
            onSaveDraft={handleSaveDraft}
            initialData={addWorkzoneData}
          />
        );
      case 'add-step3':
        return (
          <AddWorkzoneStep3 
            onBack={() => setCurrentPage('add-step2')}
            onSubmit={handleAddWorkzoneStep3}
            onSaveDraft={handleSaveDraft}
            initialData={addWorkzoneData}
          />
        );
      case 'contract':
        return (
          <ContractInfo 
            workzone={selectedWorkzone}
            onBack={() => setCurrentPage('detail')}
          />
        );
      default:
        return <WorkzoneDashboard onWorkzoneSelect={handleWorkzoneSelect} onMapClick={() => setCurrentPage('map')} onAddClick={() => setCurrentPage('add')} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-card border-b border-border px-6 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-medium text-foreground">工区信息管理</h1>
          {currentPage !== 'dashboard' && (
            <Button 
              variant="ghost" 
              onClick={() => setCurrentPage('dashboard')}
              className="flex items-center gap-2 text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="w-4 h-4" />
              返回首页
            </Button>
          )}
        </div>
      </div>
      
      <div className="flex-1">
        {renderPage()}
      </div>
      
      <Toaster />
    </div>
  );
}